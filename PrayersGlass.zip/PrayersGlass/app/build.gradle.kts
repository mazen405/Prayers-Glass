plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.prayersglass"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.prayersglass"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    lint { abortOnError = false }
}

// The app intentionally has NO third-party runtime dependencies (framework APIs only).
dependencies {
    testImplementation("junit:junit:4.13.2")
    // android.jar only ships stubs of org.json for unit tests, so use the real implementation.
    testImplementation("org.json:json:20240303")
}
