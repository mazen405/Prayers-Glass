package com.prayersglass

import com.prayersglass.domain.CalcMethods
import com.prayersglass.domain.Prayer
import com.prayersglass.domain.PrayerCalculator
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId
import java.time.temporal.ChronoUnit
import kotlin.math.abs

/** The offline fallback must land within a few minutes of published timetables. */
class PrayerCalculatorTest {
    private fun near(expected: LocalTime, actual: LocalTime, tolMin: Long) {
        val diff = abs(ChronoUnit.MINUTES.between(expected, actual))
        assertTrue("expected $expected but was $actual", diff <= tolMin)
    }

    @Test fun cairoOctober() {
        // 18 Oct 2026 is still on Cairo summer time (UTC+3). Independent sanity values: solar noon
        // ~12:40 (longitude + equation of time), sunset ~18:20, Egyptian Fajr ~05:30.
        val d = PrayerCalculator.compute(
            LocalDate.of(2026, 10, 18), 30.0444, 31.2357, ZoneId.of("Africa/Cairo"),
            CalcMethods.byId(5)!!, 0
        )
        near(LocalTime.of(5, 30), d.time(Prayer.FAJR), 15)
        near(LocalTime.of(12, 40), d.time(Prayer.DHUHR), 5)
        near(LocalTime.of(15, 55), d.time(Prayer.ASR), 8)
        near(LocalTime.of(18, 20), d.time(Prayer.MAGHRIB), 5)
        near(LocalTime.of(19, 40), d.time(Prayer.ISHA), 10)
    }

    @Test fun timesAreOrdered() {
        val d = PrayerCalculator.compute(
            LocalDate.of(2026, 1, 15), 51.5, -0.12, ZoneId.of("Europe/London"), CalcMethods.MWL, 0
        )
        val t = Prayer.ALL.map { d.time(it) }
        assertTrue(t.zipWithNext().all { (a, b) -> a.isBefore(b) })
    }

    @Test fun hanafiAsrIsLater() {
        val z = ZoneId.of("Africa/Cairo")
        val std = PrayerCalculator.compute(LocalDate.of(2026, 6, 1), 30.0444, 31.2357, z, CalcMethods.MWL, 0)
        val han = PrayerCalculator.compute(LocalDate.of(2026, 6, 1), 30.0444, 31.2357, z, CalcMethods.MWL, 1)
        assertTrue(han.time(Prayer.ASR).isAfter(std.time(Prayer.ASR)))
    }
}
