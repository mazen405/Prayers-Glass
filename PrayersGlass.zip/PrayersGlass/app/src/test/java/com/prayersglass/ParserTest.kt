package com.prayersglass

import com.prayersglass.data.AladhanClient
import com.prayersglass.data.AladhanParser
import com.prayersglass.data.ApiException
import com.prayersglass.data.CacheCodec
import com.prayersglass.domain.CalcMethods
import com.prayersglass.domain.CalcParams
import com.prayersglass.domain.Prayer
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import java.time.LocalDate
import java.time.LocalTime

class ParserTest {
    private val sample = """
    {"code":200,"status":"OK","data":[
      {"timings":{"Fajr":"04:52 (EET)","Sunrise":"06:16 (EET)","Dhuhr":"11:52 (EET)","Asr":"15:20 (EET)","Sunset":"17:28 (EET)","Maghrib":"17:58 (EET)","Isha":"19:20 (EET)"},
       "date":{"readable":"18 Oct 2026","gregorian":{"date":"18-10-2026"},
               "hijri":{"day":"6","month":{"number":4,"en":"Rabīʿ al-ākhir","ar":"رَبيع الآخر"},"year":"1448"}},
       "meta":{"timezone":"Africa/Cairo","method":{"id":5}}},
      {"timings":{"Fajr":"04:53","Sunrise":"06:17","Dhuhr":"11:51","Asr":"15:19","Sunset":"17:27","Maghrib":"17:57","Isha":"19:19"},
       "date":{"gregorian":{"date":"19-10-2026"}},"meta":{"timezone":"Africa/Cairo"}},
      {"timings":{"Fajr":"broken"},"date":{"gregorian":{"date":"20-10-2026"}}}
    ]}
    """.trimIndent()

    @Test fun parsesDaysTimesHijriAndZone() {
        val m = AladhanParser.parseCalendar(sample)
        assertEquals("Africa/Cairo", m.zoneId)
        assertEquals(2, m.days.size) // the broken entry is skipped
        val d = m.days[0]
        assertEquals(LocalDate.of(2026, 10, 18), d.date)
        assertEquals(LocalTime.of(4, 52), d.time(Prayer.FAJR))
        assertEquals(LocalTime.of(19, 20), d.time(Prayer.ISHA))
        assertEquals(6, d.hijri!!.day)
        assertEquals(1448, d.hijri!!.year)
        assertNull(m.days[1].hijri)
    }

    @Test fun rejectsGarbageAndErrors() {
        for (bad in listOf("not json", "{\"code\":400,\"data\":[]}", "{\"code\":200,\"data\":[]}", "{\"code\":200}")) {
            try {
                AladhanParser.parseCalendar(bad)
                fail("should throw for $bad")
            } catch (e: ApiException) {
                assertNotNull(e.kind)
            }
        }
    }

    @Test fun cacheRoundTrip() {
        val m = AladhanParser.parseCalendar(sample)
        val back = CacheCodec.decode(CacheCodec.encode(m))!!
        assertEquals(m.zoneId, back.zoneId)
        assertEquals(m.days.map { it.date to it.times }, back.days.map { it.date to it.times })
        assertEquals(m.days[0].hijri, back.days[0].hijri)
        assertNull(CacheCodec.decode("{broken"))
    }

    @Test fun urlContainsParameters() {
        val u = AladhanClient.buildUrl(CalcParams(30.0444, 31.2357, 5, 1), 2026, 10)
        assertTrue(u, u.startsWith("https://api.aladhan.com/v1/calendar/2026/10?"))
        assertTrue(u.contains("latitude=30.04440"))
        assertTrue(u.contains("longitude=31.23570"))
        assertTrue(u.contains("method=5"))
        assertTrue(u.contains("school=1"))
        val auto = AladhanClient.buildUrl(CalcParams(-33.9, 151.2, CalcMethods.AUTO, 0), 2026, 1)
        assertTrue(auto, !auto.contains("method="))
        assertTrue(auto.contains("latitude=-33.90000"))
    }
}
