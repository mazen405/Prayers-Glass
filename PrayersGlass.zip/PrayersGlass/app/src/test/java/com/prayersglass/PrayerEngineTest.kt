package com.prayersglass

import com.prayersglass.domain.DayTimes
import com.prayersglass.domain.Prayer
import com.prayersglass.domain.PrayerEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId
import java.time.ZonedDateTime

class PrayerEngineTest {
    private val zone = ZoneId.of("Africa/Cairo")

    private fun day(d: LocalDate, shiftMin: Int = 0) = DayTimes(
        d,
        mapOf(
            Prayer.FAJR to LocalTime.of(4, 52).plusMinutes(shiftMin.toLong()),
            Prayer.DHUHR to LocalTime.of(11, 52),
            Prayer.ASR to LocalTime.of(15, 20),
            Prayer.MAGHRIB to LocalTime.of(17, 58),
            Prayer.ISHA to LocalTime.of(19, 20)
        )
    )

    private val d0 = LocalDate.of(2026, 10, 18)
    private val days = mapOf(
        d0.minusDays(1) to day(d0.minusDays(1)),
        d0 to day(d0),
        d0.plusDays(1) to day(d0.plusDays(1), 1)
    )

    private fun at(h: Int, m: Int, s: Int = 0) =
        ZonedDateTime.of(d0, LocalTime.of(h, m, s), zone).toInstant()

    @Test fun nextPrayerMidday() {
        val s = PrayerEngine.snapshot(days, zone, at(13, 0))!!
        assertEquals(Prayer.ASR, s.next.prayer)
        assertEquals(Prayer.DHUHR, s.previous.prayer)
        assertEquals((2 * 3600 + 20 * 60).toLong(), s.remainingSeconds(at(13, 0)))
        assertFalse(s.justEntered)
    }

    @Test fun justEnteredWindowThenNormal() {
        val s1 = PrayerEngine.snapshot(days, zone, at(11, 52, 30))!!
        assertTrue(s1.justEntered)
        assertEquals(Prayer.DHUHR, s1.previous.prayer)
        assertEquals(Prayer.ASR, s1.next.prayer)
        val s2 = PrayerEngine.snapshot(days, zone, at(12, 13))!!
        assertFalse(s2.justEntered)
    }

    @Test fun afterIshaNextIsTomorrowFajr() {
        val s = PrayerEngine.snapshot(days, zone, at(21, 0))!!
        assertEquals(Prayer.FAJR, s.next.prayer)
        assertEquals(d0.plusDays(1), s.next.time.toLocalDate())
        assertEquals(LocalTime.of(4, 53), s.next.time.toLocalTime())
    }

    @Test fun beforeFajrPreviousIsYesterdayIsha() {
        val s = PrayerEngine.snapshot(days, zone, at(3, 0))!!
        assertEquals(Prayer.FAJR, s.next.prayer)
        assertEquals(Prayer.ISHA, s.previous.prayer)
        assertEquals(d0.minusDays(1), s.previous.time.toLocalDate())
    }

    @Test fun missingNeighbourDaysAreApproximated() {
        val only = mapOf(d0 to day(d0))
        val s = PrayerEngine.snapshot(only, zone, at(21, 0))!!
        assertEquals(Prayer.FAJR, s.next.prayer)
        assertTrue(s.next.approximate)
    }

    @Test fun noDataForToday() {
        assertNull(PrayerEngine.snapshot(emptyMap(), zone, at(12, 0)))
    }

    @Test fun boundaryIsEndOfBannerWhileJustEntered() {
        val s = PrayerEngine.snapshot(days, zone, at(11, 55))!!
        assertEquals(at(12, 12).toEpochMilli(), s.nextBoundary().toEpochMilli())
        val s2 = PrayerEngine.snapshot(days, zone, at(13, 0))!!
        assertEquals(at(15, 20).toEpochMilli(), s2.nextBoundary().toEpochMilli())
    }

    @Test fun progressBetweenPrayers() {
        val s = PrayerEngine.snapshot(days, zone, at(13, 36))!!
        // 11:52 -> 15:20 is 208 min; 104 min elapsed.
        assertEquals(0.5f, s.progress(at(13, 36)), 0.001f)
    }

    @Test fun daylightSavingGapDoesNotCrash() {
        // Europe/Berlin springs forward on 2026-03-29 (02:00 -> 03:00).
        val berlin = ZoneId.of("Europe/Berlin")
        val d = LocalDate.of(2026, 3, 29)
        val dayT = DayTimes(d, mapOf(
            Prayer.FAJR to LocalTime.of(2, 30), Prayer.DHUHR to LocalTime.of(13, 30),
            Prayer.ASR to LocalTime.of(17, 0), Prayer.MAGHRIB to LocalTime.of(19, 40),
            Prayer.ISHA to LocalTime.of(21, 10)))
        val now = ZonedDateTime.of(d, LocalTime.of(10, 0), berlin).toInstant()
        val s = PrayerEngine.snapshot(mapOf(d to dayT), berlin, now)!!
        assertEquals(Prayer.DHUHR, s.next.prayer)
        assertEquals(3, s.today[0].time.hour) // 02:30 does not exist -> 03:30
    }
}
