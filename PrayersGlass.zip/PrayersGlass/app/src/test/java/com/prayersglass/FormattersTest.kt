package com.prayersglass

import com.prayersglass.domain.DurationFormatter
import com.prayersglass.domain.Lang
import com.prayersglass.domain.TimeFormatter
import org.junit.Assert.assertEquals
import org.junit.Test
import java.time.LocalTime

class FormattersTest {
    private fun ar(h: Int, m: Int, s: Int = 0) =
        DurationFormatter.remaining(h * 3600L + m * 60L + s, Lang.AR)

    @Test fun arabicExampleFromSpec() = assertEquals("متبقي ساعتان و6 دقائق", ar(2, 6))
    @Test fun arabicSingularAndDual() {
        assertEquals("متبقي ساعة", ar(1, 0))
        assertEquals("متبقي ساعة ودقيقة", ar(1, 1))
        assertEquals("متبقي دقيقتان", ar(0, 2))
        assertEquals("متبقي ساعتان ودقيقتان", ar(2, 2))
    }
    @Test fun arabicPluralRanges() {
        assertEquals("متبقي 3 ساعات", ar(3, 0))
        assertEquals("متبقي 10 ساعات و10 دقائق", ar(10, 10))
        assertEquals("متبقي 11 ساعة و11 دقيقة", ar(11, 11))
        assertEquals("متبقي 45 دقيقة", ar(0, 45))
    }
    @Test fun secondsRoundUpToNextMinute() {
        assertEquals("متبقي ساعتان و6 دقائق", ar(2, 5, 1))
        assertEquals("متبقي 3 ساعات", ar(2, 59, 30))
    }
    @Test fun lessThanAMinute() {
        assertEquals("متبقي أقل من دقيقة", ar(0, 0, 30))
        assertEquals("Less than a minute left", DurationFormatter.remaining(30, Lang.EN))
        assertEquals("متبقي أقل من دقيقة", DurationFormatter.remaining(-5, Lang.AR))
    }
    @Test fun english() {
        assertEquals("2 hr 6 min left", DurationFormatter.remaining(2 * 3600L + 6 * 60L, Lang.EN))
        assertEquals("45 min left", DurationFormatter.remaining(45 * 60L, Lang.EN))
        assertEquals("3 hr left", DurationFormatter.remaining(3 * 3600L, Lang.EN))
    }
    @Test fun clock() {
        assertEquals("2:06", DurationFormatter.clock(2 * 3600L + 6 * 60L))
        assertEquals("0:42", DurationFormatter.clock(41 * 60L + 10))
    }
    @Test fun timeFormatting() {
        assertEquals("12:05", TimeFormatter.hm(LocalTime.of(0, 5), false))
        assertEquals("4:56", TimeFormatter.hm(LocalTime.of(16, 56), false))
        assertEquals("16:56", TimeFormatter.hm(LocalTime.of(16, 56), true))
        assertEquals("م", TimeFormatter.meridiem(LocalTime.of(16, 56), Lang.AR, false))
        assertEquals("AM", TimeFormatter.meridiem(LocalTime.of(4, 56), Lang.EN, false))
        assertEquals("", TimeFormatter.meridiem(LocalTime.of(4, 56), Lang.EN, true))
        assertEquals("4:56 ص", TimeFormatter.full(LocalTime.of(4, 56), Lang.AR, false))
    }
}
