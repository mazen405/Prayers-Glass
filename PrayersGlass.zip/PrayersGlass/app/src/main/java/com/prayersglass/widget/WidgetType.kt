package com.prayersglass.widget

import com.prayersglass.R

/** The five widget designs. Each ships one or more fixed sizes ([WidgetType]). */
enum class Design(
    val id: String,
    val nameRes: Int,
    val descRes: Int,
    /** Default glass opacity (percent). */
    val defaultOpacity: Int,
    /** Base darkness of the tint laid over the backdrop, 0..1. */
    val tint: Float,
    /** Strength of the glossy highlights, 0..1. */
    val sheen: Float,
    /** Adds a soft accent glow in the upper corner. */
    val glow: Boolean
) {
    LIQUID_GLASS("liquid_glass", R.string.design_liquid_glass, R.string.design_liquid_glass_desc, 94, 0.40f, 1.0f, false),
    NEXT_PRAYER("next_prayer", R.string.design_next_prayer, R.string.design_next_prayer_desc, 94, 0.38f, 1.0f, true),
    PRAYER_STRIP("prayer_strip", R.string.design_prayer_strip, R.string.design_prayer_strip_desc, 94, 0.42f, 0.85f, false),
    PRAYER_CIRCLES("prayer_circles", R.string.design_prayer_circles, R.string.design_prayer_circles_desc, 94, 0.40f, 0.9f, true),
    MINIMAL_GLASS("minimal_glass", R.string.design_minimal_glass, R.string.design_minimal_glass_desc, 62, 0.30f, 0.6f, false);

    companion object {
        fun fromId(id: String?): Design? = values().firstOrNull { it.id == id }
    }
}

/** A concrete launcher widget: one design at one size. Each has its own receiver + provider XML. */
enum class WidgetType(
    val id: String,
    val design: Design,
    val cols: Int,
    val rows: Int,
    val layoutRes: Int,
    /** Typical size in dp used for in-app previews (real size comes from the launcher). */
    val previewWidthDp: Int,
    val previewHeightDp: Int
) {
    LIQUID_GLASS_4X2("lg_4x2", Design.LIQUID_GLASS, 4, 2, R.layout.widget_liquid_glass_4x2, 340, 150),
    NEXT_PRAYER_2X2("np_2x2", Design.NEXT_PRAYER, 2, 2, R.layout.widget_next_prayer_2x2, 150, 150),
    NEXT_PRAYER_4X1("np_4x1", Design.NEXT_PRAYER, 4, 1, R.layout.widget_next_prayer_4x1, 340, 72),
    PRAYER_STRIP_4X1("ps_4x1", Design.PRAYER_STRIP, 4, 1, R.layout.widget_prayer_strip_4x1, 340, 72),
    PRAYER_CIRCLES_4X2("pc_4x2", Design.PRAYER_CIRCLES, 4, 2, R.layout.widget_prayer_circles_4x2, 340, 150),
    MINIMAL_GLASS_2X2("mg_2x2", Design.MINIMAL_GLASS, 2, 2, R.layout.widget_minimal_glass_2x2, 150, 150),
    MINIMAL_GLASS_4X1("mg_4x1", Design.MINIMAL_GLASS, 4, 1, R.layout.widget_minimal_glass_4x1, 340, 72);

    val sizeLabel: String get() = "$cols×$rows"

    /** The AppWidgetProvider that hosts this type. (A `when` avoids enum <-> class init cycles.) */
    val receiverClass: Class<*>
        get() = when (this) {
            LIQUID_GLASS_4X2 -> LiquidGlass4x2Provider::class.java
            NEXT_PRAYER_2X2 -> NextPrayer2x2Provider::class.java
            NEXT_PRAYER_4X1 -> NextPrayer4x1Provider::class.java
            PRAYER_STRIP_4X1 -> PrayerStrip4x1Provider::class.java
            PRAYER_CIRCLES_4X2 -> PrayerCircles4x2Provider::class.java
            MINIMAL_GLASS_2X2 -> MinimalGlass2x2Provider::class.java
            MINIMAL_GLASS_4X1 -> MinimalGlass4x1Provider::class.java
        }

    companion object {
        fun fromId(id: String?): WidgetType? = values().firstOrNull { it.id == id }
        fun forDesign(d: Design): List<WidgetType> = values().filter { it.design == d }
    }
}
