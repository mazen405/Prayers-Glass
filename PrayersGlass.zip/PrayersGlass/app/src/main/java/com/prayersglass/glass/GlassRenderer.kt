package com.prayersglass.glass

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.util.LruCache
import com.prayersglass.widget.Design
import kotlin.math.max
import kotlin.math.min

/** A tiny, heavily blurred version of the user's photo plus its average brightness. */
class Backdrop(val bitmap: Bitmap, val luminance: Float)

object BackdropCache {
    private val cache = LruCache<String, Backdrop>(6)

    fun get(ctx: Context, name: String): Backdrop? {
        val f = BackgroundStore.file(ctx, name) ?: return null
        val key = name + "@" + f.lastModified()
        cache.get(key)?.let { return it }
        val built = build(f.absolutePath) ?: return null
        cache.put(key, built)
        return built
    }

    fun invalidate(name: String) {
        for (k in cache.snapshot().keys) if (k.startsWith("$name@")) cache.remove(k)
    }

    private fun build(path: String): Backdrop? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(path, bounds)
        if (bounds.outWidth <= 0) return null
        var sample = 1
        while (max(bounds.outWidth, bounds.outHeight) / (sample * 2) >= 256) sample *= 2
        val decoded = BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = sample })
            ?: return null
        val scale = 112f / max(decoded.width, decoded.height)
        val small = if (scale < 1f) {
            Bitmap.createScaledBitmap(
                decoded,
                max(1, (decoded.width * scale).toInt()),
                max(1, (decoded.height * scale).toInt()),
                true
            )
        } else decoded
        val blurred = ImageBlur.blur(small, radius = 4, passes = 3)
        if (small !== decoded) decoded.recycle()
        if (blurred !== small) small.recycle()

        val px = IntArray(blurred.width * blurred.height)
        blurred.getPixels(px, 0, blurred.width, 0, 0, blurred.width, blurred.height)
        var sum = 0.0
        for (p in px) {
            sum += 0.299 * ((p shr 16) and 0xFF) + 0.587 * ((p shr 8) and 0xFF) + 0.114 * (p and 0xFF)
        }
        return Backdrop(blurred, (sum / px.size / 255.0).toFloat())
    }
}

/**
 * Paints the "liquid glass" card that sits behind every widget (and the in-app preview):
 * blurred photo (or a built-in gradient), a darkening tint that adapts to the photo's brightness
 * so white text stays readable, glossy highlights, and a light-catching border.
 *
 * RemoteViews cannot blur live content behind a widget, so the glass is composed here from the
 * user's chosen photo instead.
 */
object GlassRenderer {
    const val ACCENT = 0xFF6CB8FF.toInt()
    private const val CORNER_DP = 24f

    /**
     * @param pxPerDp pixels per dp of the bitmap (corner radius and border scale with it)
     */
    fun render(ctx: Context, wPx: Int, hPx: Int, pxPerDp: Float, bgName: String?, design: Design): Bitmap {
        val w = max(2, wPx)
        val h = max(2, hPx)
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val wf = w.toFloat()
        val hf = h.toFloat()
        val radius = min(CORNER_DP * pxPerDp, min(wf, hf) / 2f)

        val backdrop = bgName?.let { BackdropCache.get(ctx, it) }
        if (backdrop != null) drawCover(c, backdrop.bitmap, wf, hf) else drawDefaultBackdrop(c, wf, hf)
        val lum = backdrop?.luminance ?: 0.24f

        // Adaptive tint: brighter photos get a darker veil so white text keeps its contrast.
        val tintAlpha = (design.tint + 0.30f * lum).coerceIn(0.26f, 0.74f)
        c.drawColor(Color.argb((tintAlpha * 255).toInt(), 8, 18, 36))

        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        val s = design.sheen

        // Diagonal sheen.
        p.shader = LinearGradient(
            0f, 0f, wf * 0.9f, hf,
            intArrayOf(argb(0.20f * s, 255, 255, 255), argb(0.05f * s, 255, 255, 255), argb(0f, 255, 255, 255)),
            floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP
        )
        c.drawRect(0f, 0f, wf, hf, p)

        // Specular highlight in the upper-left corner.
        val r = max(wf, hf) * 0.75f
        p.shader = RadialGradient(
            wf * 0.12f, -hf * 0.15f, r,
            intArrayOf(argb(0.16f * s, 255, 255, 255), argb(0f, 255, 255, 255)),
            floatArrayOf(0f, 1f), Shader.TileMode.CLAMP
        )
        c.drawRect(0f, 0f, wf, hf, p)

        // Optional accent glow (upper-right).
        if (design.glow) {
            p.shader = RadialGradient(
                wf * 0.88f, hf * 0.12f, max(hf, wf * 0.35f) * 0.95f,
                intArrayOf(argb(0.30f, 108, 184, 255), argb(0f, 108, 184, 255)),
                floatArrayOf(0f, 1f), Shader.TileMode.CLAMP
            )
            c.drawRect(0f, 0f, wf, hf, p)
        }

        // Soft shade along the bottom edge.
        p.shader = LinearGradient(
            0f, hf * 0.5f, 0f, hf,
            argb(0f, 0, 0, 0), argb(0.22f, 0, 0, 0), Shader.TileMode.CLAMP
        )
        c.drawRect(0f, 0f, wf, hf, p)
        p.shader = null

        // Round the corners: clear everything outside the rounded rectangle (anti-aliased).
        val outside = Path().apply {
            addRoundRect(RectF(0f, 0f, wf, hf), radius, radius, Path.Direction.CW)
            fillType = Path.FillType.INVERSE_WINDING
        }
        val eraser = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
        }
        c.drawPath(outside, eraser)

        // Light-catching border: bright at the top-left, faint at the bottom-right.
        val stroke = max(1f, 1.3f * pxPerDp)
        val border = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = stroke
            shader = LinearGradient(
                0f, 0f, wf, hf,
                intArrayOf(
                    argb(0.62f, 255, 255, 255), argb(0.16f, 255, 255, 255),
                    argb(0.10f, 255, 255, 255), argb(0.42f, 255, 255, 255)
                ),
                floatArrayOf(0f, 0.35f, 0.7f, 1f), Shader.TileMode.CLAMP
            )
        }
        val inset = stroke / 2f
        c.drawRoundRect(RectF(inset, inset, wf - inset, hf - inset), radius - inset, radius - inset, border)
        return bmp
    }

    /** Full-screen blurred background for the app itself. */
    fun renderPage(ctx: Context, wPx: Int, hPx: Int, bgName: String?): Bitmap {
        val bmp = Bitmap.createBitmap(max(2, wPx), max(2, hPx), Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val wf = bmp.width.toFloat()
        val hf = bmp.height.toFloat()
        val backdrop = bgName?.let { BackdropCache.get(ctx, it) }
        if (backdrop != null) {
            drawCover(c, backdrop.bitmap, wf, hf)
            val a = (0.52f + 0.25f * backdrop.luminance).coerceIn(0.5f, 0.78f)
            c.drawColor(Color.argb((a * 255).toInt(), 6, 14, 30))
        } else {
            drawDefaultBackdrop(c, wf, hf)
            c.drawColor(Color.argb(60, 4, 10, 24))
        }
        return bmp
    }

    private fun argb(alpha: Float, r: Int, g: Int, b: Int): Int =
        Color.argb((alpha.coerceIn(0f, 1f) * 255).toInt(), r, g, b)

    private fun drawCover(c: Canvas, src: Bitmap, w: Float, h: Float) {
        val scale = max(w / src.width, h / src.height)
        val m = Matrix()
        m.postScale(scale, scale)
        m.postTranslate((w - src.width * scale) / 2f, (h - src.height * scale) / 2f)
        c.drawBitmap(src, m, Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG))
    }

    /** Deep blue base with a few soft colour blobs, so glass looks rich even with no photo. */
    private fun drawDefaultBackdrop(c: Canvas, w: Float, h: Float) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.shader = LinearGradient(
            0f, 0f, w, h,
            intArrayOf(0xFF0B1F3C.toInt(), 0xFF173A66.toInt(), 0xFF2A4F7E.toInt()),
            floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
        )
        c.drawRect(0f, 0f, w, h, p)
        val big = max(w, h)
        fun blob(cx: Float, cy: Float, radius: Float, rgb: Int, alpha: Float) {
            p.shader = RadialGradient(
                cx, cy, radius,
                intArrayOf(
                    Color.argb((alpha * 255).toInt(), Color.red(rgb), Color.green(rgb), Color.blue(rgb)),
                    Color.argb(0, Color.red(rgb), Color.green(rgb), Color.blue(rgb))
                ),
                floatArrayOf(0f, 1f), Shader.TileMode.CLAMP
            )
            c.drawRect(0f, 0f, w, h, p)
        }
        blob(w * 0.15f, h * 0.10f, big * 0.55f, 0x3B9CFF, 0.50f)
        blob(w * 0.90f, h * 1.00f, big * 0.60f, 0x7C6BFF, 0.36f)
        blob(w * 0.65f, h * 0.00f, big * 0.35f, 0x2CD6C4, 0.20f)
        p.shader = null
    }
}

/** Draws the circular progress rings of the "Prayer Circles" design. */
object RingRenderer {
    enum class State { PASSED, UPCOMING, NEXT, CURRENT }

    fun render(sizePx: Int, state: State, progress: Float): Bitmap {
        val size = max(8, sizePx)
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val stroke = size * 0.075f
        val pad = stroke * 1.6f
        val rect = RectF(pad, pad, size - pad, size - pad)

        val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
        val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = stroke
            strokeCap = Paint.Cap.ROUND
        }
        val accent = GlassRenderer.ACCENT
        when (state) {
            State.PASSED -> {
                fill.color = Color.argb(26, 255, 255, 255)
                c.drawOval(rect, fill)
                ring.color = Color.argb(80, 255, 255, 255)
                c.drawOval(rect, ring)
            }
            State.UPCOMING -> {
                fill.color = Color.argb(20, 255, 255, 255)
                c.drawOval(rect, fill)
                ring.color = Color.argb(105, 255, 255, 255)
                c.drawOval(rect, ring)
            }
            State.NEXT -> {
                fill.color = Color.argb(58, Color.red(accent), Color.green(accent), Color.blue(accent))
                c.drawOval(rect, fill)
                ring.color = Color.argb(56, 255, 255, 255)
                c.drawOval(rect, ring)
                val sweep = 360f * progress.coerceIn(0.02f, 1f)
                val glow = Paint(ring).apply {
                    color = Color.argb(110, Color.red(accent), Color.green(accent), Color.blue(accent))
                    strokeWidth = stroke * 1.8f
                    maskFilter = BlurMaskFilter(stroke * 0.9f, BlurMaskFilter.Blur.NORMAL)
                }
                c.drawArc(rect, -90f, sweep, false, glow)
                ring.color = accent
                c.drawArc(rect, -90f, sweep, false, ring)
            }
            State.CURRENT -> {
                fill.color = Color.argb(90, Color.red(accent), Color.green(accent), Color.blue(accent))
                c.drawOval(rect, fill)
                ring.color = accent
                c.drawOval(rect, ring)
            }
        }
        return bmp
    }
}
