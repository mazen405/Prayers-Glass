package com.prayersglass.widget

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.SystemClock
import java.time.Instant

/**
 * Refresh strategy (kept deliberately battery friendly):
 *
 *  * An inexact, NON-wakeup alarm roughly every minute. It only fires while the device is awake,
 *    so the countdown stays fresh while the user is looking at the screen and costs nothing while
 *    the phone sleeps. Android does not allow widgets to tick every second.
 *  * One inexact wake-up alarm at the next prayer time so the highlighted prayer switches even if
 *    the screen was off. Without the exact-alarm permission Android may deliver it a little late
 *    (notably in Doze).
 *  * A periodic job (see [RefreshJobService]) that downloads fresh timings in the background.
 */
object Scheduler {
    const val ACTION_TICK = "com.prayersglass.action.TICK"
    private const val REQ_TICK = 1
    private const val REQ_BOUNDARY = 2

    private fun pending(ctx: Context, req: Int): PendingIntent = PendingIntent.getBroadcast(
        ctx, req,
        Intent(ctx, TickReceiver::class.java).setAction(ACTION_TICK),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    fun schedule(ctx: Context, boundary: Instant?) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val toNextMinute = 60_000L - (System.currentTimeMillis() % 60_000L) + 500L
        am.set(
            AlarmManager.ELAPSED_REALTIME,
            SystemClock.elapsedRealtime() + toNextMinute,
            pending(ctx, REQ_TICK)
        )
        if (boundary != null) {
            am.setAndAllowWhileIdle(
                AlarmManager.RTC_WAKEUP, boundary.toEpochMilli() + 1_000L, pending(ctx, REQ_BOUNDARY)
            )
        } else {
            am.cancel(pending(ctx, REQ_BOUNDARY))
        }
        RefreshJobService.ensurePeriodic(ctx)
    }

    fun cancelAll(ctx: Context) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(pending(ctx, REQ_TICK))
        am.cancel(pending(ctx, REQ_BOUNDARY))
        RefreshJobService.cancelAll(ctx)
    }
}
