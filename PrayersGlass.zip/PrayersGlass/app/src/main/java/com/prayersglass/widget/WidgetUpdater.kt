package com.prayersglass.widget

import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.res.Configuration
import com.prayersglass.data.PrayerData
import com.prayersglass.data.SettingsStore
import com.prayersglass.data.TimesRepository
import com.prayersglass.data.WidgetConfig
import com.prayersglass.domain.DataSource
import com.prayersglass.domain.PrayerEngine
import java.time.Instant

/** Central place that (re)draws every placed widget and schedules the next refresh. */
object WidgetUpdater {

    private const val RETRY_SYNC_AFTER_MS = 15 * 60 * 1000L

    fun hasAnyWidget(ctx: Context): Boolean {
        val awm = AppWidgetManager.getInstance(ctx)
        return WidgetType.values().any {
            awm.getAppWidgetIds(ComponentName(ctx, it.receiverClass)).isNotEmpty()
        }
    }

    /** Ids of all placed widgets together with their type. */
    fun placedWidgets(ctx: Context): List<Pair<Int, WidgetType>> {
        val awm = AppWidgetManager.getInstance(ctx)
        val out = ArrayList<Pair<Int, WidgetType>>()
        for (t in WidgetType.values()) {
            for (id in awm.getAppWidgetIds(ComponentName(ctx, t.receiverClass))) out.add(id to t)
        }
        return out
    }

    /**
     * Returns the stored configuration of a widget. A brand-new widget first receives the
     * configuration the user just designed in the gallery (see [SettingsStore.setPending]); if it
     * was added straight from the launcher's widget list it starts from the gallery's current draft.
     */
    fun configFor(store: SettingsStore, id: Int, type: WidgetType): WidgetConfig {
        store.widgetConfig(id)?.takeIf { it.type == type }?.let { return it }
        val cfg = store.claimPending(type) ?: store.draft.let {
            WidgetConfig(type, it.lang, it.bgFile, it.opacity, it.showLocation)
        }
        store.saveWidgetConfig(id, cfg)
        return cfg
    }

    fun sizeFor(ctx: Context, awm: AppWidgetManager, id: Int, type: WidgetType): SizeDp {
        val o = awm.getAppWidgetOptions(id)
        val landscape = ctx.resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        val w = if (landscape) o.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_WIDTH, 0)
        else o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 0)
        val h = if (landscape) o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 0)
        else o.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 0)
        return if (w > 0 && h > 0) SizeDp(w, h) else SizeDp(type.previewWidthDp, type.previewHeightDp)
    }

    /**
     * @param onlyIds restrict the update to these widget ids (others are left untouched)
     */
    fun updateAll(ctx: Context, mode: WidgetRenderer.Mode, onlyIds: Set<Int>? = null) {
        val app = ctx.applicationContext
        val awm = AppWidgetManager.getInstance(app)
        val store = SettingsStore.get(app)
        val now = Instant.now()
        var any = false
        var data: PrayerData? = null
        var loaded = false

        for (type in WidgetType.values()) {
            val ids = awm.getAppWidgetIds(ComponentName(app, type.receiverClass))
            for (id in ids) {
                any = true
                if (onlyIds != null && id !in onlyIds) continue
                if (!loaded) {
                    data = TimesRepository.load(app, store, now)
                    loaded = true
                }
                val cfg = configFor(store, id, type)
                val effective = if (mode == WidgetRenderer.Mode.TEXT && !store.isFullyRendered(id))
                    WidgetRenderer.Mode.FULL else mode
                try {
                    val rv = WidgetRenderer.build(
                        app, type, cfg, data, now, sizeFor(app, awm, id, type), effective, false
                    )
                    if (effective == WidgetRenderer.Mode.FULL) {
                        awm.updateAppWidget(id, rv)
                        if (!store.isFullyRendered(id)) store.setFullyRendered(id, true)
                    } else {
                        awm.partiallyUpdateAppWidget(id, rv)
                    }
                } catch (e: RuntimeException) {
                    // Never let one broken widget take the others (or the receiver) down.
                    store.setFullyRendered(id, false)
                }
            }
        }

        if (!any) {
            Scheduler.cancelAll(app)
            return
        }
        if (!loaded) data = TimesRepository.load(app, store, now)
        val snap = data?.let { PrayerEngine.snapshot(it.days, it.zone, now) }
        Scheduler.schedule(app, snap?.nextBoundary())

        // Offline numbers (or none at all): quietly try the network again now and then.
        val needsOnline = data == null || data.source == DataSource.LOCAL
        if (needsOnline && now.toEpochMilli() - store.lastAttemptMs > RETRY_SYNC_AFTER_MS) {
            RefreshJobService.runNow(app)
        }
    }
}
