package com.prayersglass.util

import android.content.Context
import android.content.res.Configuration
import android.util.TypedValue
import com.prayersglass.domain.Lang
import java.util.Locale

object LocaleUtil {
    /** A context whose resources (strings, layout direction) follow [lang] instead of the device. */
    fun wrap(base: Context, lang: Lang): Context {
        val locale = Locale.forLanguageTag(lang.tag)
        val cfg = Configuration(base.resources.configuration)
        cfg.setLocale(locale)
        cfg.setLayoutDirection(locale)
        return base.createConfigurationContext(cfg)
    }
}

fun Context.dp(value: Float): Float =
    TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, value, resources.displayMetrics)

fun Context.dpInt(value: Int): Int = dp(value.toFloat()).toInt()
