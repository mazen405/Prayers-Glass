package com.prayersglass.glass

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import java.io.File
import java.io.FileOutputStream

/**
 * Owns the user's background photos.
 *
 * A picked image is *copied* (downscaled, EXIF-rotated, JPEG) into app-private storage, so no
 * persistable URI permission is needed and the widget keeps working if the original is deleted.
 * The blurred low-resolution backdrop used for the glass effect is derived from this copy by
 * [BackdropCache].
 */
object BackgroundStore {
    private const val MAX_SIDE = 1280

    private fun dir(ctx: Context): File = File(ctx.filesDir, "backgrounds").also { it.mkdirs() }

    fun file(ctx: Context, name: String?): File? {
        if (name.isNullOrEmpty() || name.contains('/')) return null
        return File(dir(ctx), name).takeIf { it.isFile }
    }

    /** Blocking. Returns the stored file name, or null if the image could not be decoded. */
    fun importFromUri(ctx: Context, uri: Uri): String? {
        val resolver = ctx.contentResolver
        return try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null

            var sample = 1
            while (maxOf(bounds.outWidth, bounds.outHeight) / sample > MAX_SIDE * 2) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            var bmp = resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
                ?: return null

            val orientation = resolver.openInputStream(uri)?.use {
                ExifInterface(it).getAttributeInt(
                    ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL
                )
            } ?: ExifInterface.ORIENTATION_NORMAL

            val m = Matrix()
            val longest = maxOf(bmp.width, bmp.height)
            if (longest > MAX_SIDE) {
                val s = MAX_SIDE.toFloat() / longest
                m.postScale(s, s)
            }
            when (orientation) {
                ExifInterface.ORIENTATION_ROTATE_90 -> m.postRotate(90f)
                ExifInterface.ORIENTATION_ROTATE_180 -> m.postRotate(180f)
                ExifInterface.ORIENTATION_ROTATE_270 -> m.postRotate(270f)
            }
            if (!m.isIdentity) {
                val scaled = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
                if (scaled !== bmp) bmp.recycle()
                bmp = scaled
            }

            val name = "bg_${System.currentTimeMillis()}.jpg"
            FileOutputStream(File(dir(ctx), name)).use { bmp.compress(Bitmap.CompressFormat.JPEG, 88, it) }
            bmp.recycle()
            name
        } catch (e: Exception) {
            null
        }
    }

    /** Deletes stored backgrounds that nothing references anymore. */
    fun cleanup(ctx: Context, keep: Set<String>) {
        dir(ctx).listFiles()?.forEach { f ->
            if (f.name !in keep) {
                f.delete()
                BackdropCache.invalidate(f.name)
            }
        }
    }
}
