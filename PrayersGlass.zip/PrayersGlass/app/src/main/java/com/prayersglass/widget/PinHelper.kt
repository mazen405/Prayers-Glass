package com.prayersglass.widget

import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import com.prayersglass.data.SettingsStore
import com.prayersglass.data.WidgetConfig

object PinHelper {
    fun isSupported(ctx: Context): Boolean =
        AppWidgetManager.getInstance(ctx).isRequestPinAppWidgetSupported

    /**
     * Asks the launcher to pin a widget of [cfg].type. The designed configuration is remembered
     * first so the widget that appears picks it up (see [WidgetUpdater.configFor]).
     *
     * @return false when the launcher does not support in-app pinning.
     */
    fun request(ctx: Context, cfg: WidgetConfig): Boolean {
        // Remember the design first: it is also used if the user adds the widget manually.
        SettingsStore.get(ctx).setPending(cfg)
        val awm = AppWidgetManager.getInstance(ctx)
        if (!awm.isRequestPinAppWidgetSupported) return false
        return awm.requestPinAppWidget(ComponentName(ctx, cfg.type.receiverClass), null, null)
    }
}
