package com.prayersglass.domain

import java.time.LocalTime

/** Human readable countdowns, with correct Arabic number agreement. */
object DurationFormatter {

    /** e.g. "متبقي ساعتان و6 دقائق" / "2 hr 6 min left". Minutes are rounded up. */
    fun remaining(totalSeconds: Long, lang: Lang): String {
        val secs = maxOf(0L, totalSeconds)
        if (secs < 60) {
            return if (lang == Lang.AR) "متبقي أقل من دقيقة" else "Less than a minute left"
        }
        val totalMin = (secs + 59) / 60
        val h = (totalMin / 60).toInt()
        val m = (totalMin % 60).toInt()
        return if (lang == Lang.AR) {
            val parts = ArrayList<String>()
            if (h > 0) parts.add(arabicHours(h))
            if (m > 0) parts.add(arabicMinutes(m))
            "متبقي " + parts.joinToString(" و")
        } else {
            val parts = ArrayList<String>()
            if (h > 0) parts.add("$h hr")
            if (m > 0) parts.add("$m min")
            parts.joinToString(" ") + " left"
        }
    }

    /** Compact "h:mm" (minutes rounded up), ASCII digits. */
    fun clock(totalSeconds: Long): String {
        val totalMin = (maxOf(0L, totalSeconds) + 59) / 60
        val h = totalMin / 60
        val m = totalMin % 60
        return "$h:" + (if (m < 10) "0$m" else "$m")
    }

    fun arabicHours(h: Int): String = when {
        h == 1 -> "ساعة"
        h == 2 -> "ساعتان"
        h in 3..10 -> "$h ساعات"
        else -> "$h ساعة"
    }

    fun arabicMinutes(m: Int): String = when {
        m == 1 -> "دقيقة"
        m == 2 -> "دقيقتان"
        m in 3..10 -> "$m دقائق"
        else -> "$m دقيقة"
    }
}

/** Clock formatting with ASCII digits (independent of the device locale's digit shapes). */
object TimeFormatter {
    private fun two(n: Int) = if (n < 10) "0$n" else "$n"

    /** "4:56" in 12-hour mode, "04:56" in 24-hour mode. */
    fun hm(t: LocalTime, is24h: Boolean): String {
        if (is24h) return two(t.hour) + ":" + two(t.minute)
        val h = t.hour % 12
        return (if (h == 0) 12 else h).toString() + ":" + two(t.minute)
    }

    /** "ص"/"م" or "AM"/"PM". Empty in 24-hour mode. */
    fun meridiem(t: LocalTime, lang: Lang, is24h: Boolean): String {
        if (is24h) return ""
        val am = t.hour < 12
        return if (lang == Lang.AR) (if (am) "ص" else "م") else (if (am) "AM" else "PM")
    }

    fun full(t: LocalTime, lang: Lang, is24h: Boolean): String {
        val m = meridiem(t, lang, is24h)
        return if (m.isEmpty()) hm(t, is24h) else hm(t, is24h) + " " + m
    }
}
