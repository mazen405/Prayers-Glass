package com.prayersglass.widget

import android.content.Context
import com.prayersglass.R
import com.prayersglass.data.LocationInfo
import com.prayersglass.data.LocationSource
import com.prayersglass.data.PrayerData
import com.prayersglass.data.SettingsStore
import com.prayersglass.data.WidgetConfig
import com.prayersglass.domain.DataSource
import com.prayersglass.domain.DurationFormatter
import com.prayersglass.domain.Lang
import com.prayersglass.domain.Prayer
import com.prayersglass.domain.PrayerEngine
import com.prayersglass.domain.TimeFormatter
import java.time.Instant
import java.time.format.DateTimeFormatter
import java.util.Locale

enum class Status { OK, LOADING, NO_DATA }
enum class RowState { PASSED, UPCOMING, NEXT, CURRENT }

class RowModel(val name: String, val time: String, val state: RowState)

/** Everything the layouts display, already formatted for one language. */
class WidgetModel(
    val status: Status,
    val statusMessage: String,
    /** "Next prayer" caption (or "Now" while a prayer has just begun). */
    val label: String,
    /** Prayer name, or "It's time for Dhuhr" right after the prayer begins. */
    val headline: String,
    val time: String,
    val ampm: String,
    /** "h:mm" countdown; empty while a prayer has just begun. */
    val bigCountdown: String,
    /** "Time left …" phrase, or "Next: Asr 3:20 PM" while a prayer has just begun. */
    val countdown: String,
    val rows: List<RowModel>,
    /** Location (and date) for the header; null when the user hides the location. */
    val locationLine: String?,
    val progress: Float,
    /** Index (0..4) of the highlighted row, or -1. */
    val activeIndex: Int
) {
    /** "4:56 م" – time and meridiem together, for compact layouts. */
    val timeWithMeridiem: String get() = if (ampm.isEmpty()) time else "$time $ampm"
}

object ModelBuilder {

    fun prayerName(lc: Context, p: Prayer): String = lc.getString(
        when (p) {
            Prayer.FAJR -> R.string.prayer_fajr
            Prayer.DHUHR -> R.string.prayer_dhuhr
            Prayer.ASR -> R.string.prayer_asr
            Prayer.MAGHRIB -> R.string.prayer_maghrib
            Prayer.ISHA -> R.string.prayer_isha
        }
    )

    /** "Cairo (default)", "Alexandria", or coordinates when no name is known. */
    fun locationText(lc: Context, loc: LocationInfo): String {
        val base = loc.name
            ?: if (loc.source == LocationSource.DEFAULT) lc.getString(R.string.city_cairo)
            else String.format(Locale.US, "%.2f, %.2f", loc.lat, loc.lon)
        return if (loc.source == LocationSource.DEFAULT) base + " " + lc.getString(R.string.location_default_suffix)
        else base
    }

    fun message(lc: Context, status: Status): String = lc.getString(
        if (status == Status.LOADING) R.string.status_loading else R.string.status_no_data
    )

    private fun empty(lc: Context, status: Status) = WidgetModel(
        status, message(lc, status), "", "", "", "", "", "", emptyList(), null, 0f, -1
    )

    fun build(
        lc: Context,
        cfg: WidgetConfig,
        data: PrayerData?,
        settings: SettingsStore,
        now: Instant,
        is24h: Boolean
    ): WidgetModel {
        if (data == null) {
            return empty(lc, if (settings.lastError != null) Status.NO_DATA else Status.LOADING)
        }
        val snap = PrayerEngine.snapshot(data.days, data.zone, now) ?: return empty(lc, Status.NO_DATA)
        val lang = cfg.lang

        val rows = ArrayList<RowModel>(5)
        var active = -1
        snap.today.forEachIndexed { i, pi ->
            val isCurrent = snap.justEntered && pi.prayer == snap.previous.prayer &&
                snap.previous.time.toLocalDate() == snap.date
            val isNext = !snap.justEntered && pi.prayer == snap.next.prayer
            val state = when {
                isCurrent -> RowState.CURRENT
                isNext -> RowState.NEXT
                !pi.time.toInstant().isAfter(now) -> RowState.PASSED
                else -> RowState.UPCOMING
            }
            if (state == RowState.CURRENT || state == RowState.NEXT) active = i
            val t = if (state == RowState.NEXT) snap.next.time.toLocalTime() else pi.time.toLocalTime()
            rows.add(RowModel(prayerName(lc, pi.prayer), TimeFormatter.hm(t, is24h), state))
        }

        val headline: String
        val label: String
        val shown: java.time.LocalTime
        val big: String
        val countdown: String
        if (snap.justEntered) {
            val cur = prayerName(lc, snap.previous.prayer)
            headline = lc.getString(R.string.label_prayer_time_now, cur)
            label = lc.getString(R.string.label_now)
            shown = snap.previous.time.toLocalTime()
            big = ""
            countdown = lc.getString(
                R.string.label_then_next,
                prayerName(lc, snap.next.prayer),
                TimeFormatter.full(snap.next.time.toLocalTime(), lang, is24h)
            )
        } else {
            headline = prayerName(lc, snap.next.prayer)
            label = lc.getString(R.string.label_next_prayer)
            shown = snap.next.time.toLocalTime()
            val secs = snap.remainingSeconds(now)
            big = DurationFormatter.clock(secs)
            countdown = DurationFormatter.remaining(secs, lang)
        }

        val dateText = DateTimeFormatter.ofPattern("EEE d MMM", Locale.forLanguageTag(lang.tag))
            .format(now.atZone(snap.zone))
        val approx = if (snap.source == DataSource.LOCAL) " · " + lc.getString(R.string.tag_approximate) else ""
        val locationLine = if (cfg.showLocation) {
            locationText(lc, data.location) + approx + " · " + dateText
        } else null

        return WidgetModel(
            status = Status.OK,
            statusMessage = "",
            label = label,
            headline = headline,
            time = TimeFormatter.hm(shown, is24h),
            ampm = TimeFormatter.meridiem(shown, lang, is24h),
            bigCountdown = big,
            countdown = countdown,
            rows = rows,
            locationLine = locationLine,
            progress = snap.progress(now),
            activeIndex = active
        )
    }
}
