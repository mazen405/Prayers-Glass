package com.prayersglass.glass

import android.graphics.Bitmap

/** Small, dependency-free box blur (run on tiny bitmaps; the result is upscaled with filtering). */
object ImageBlur {

    fun blur(src: Bitmap, radius: Int, passes: Int = 3): Bitmap {
        val w = src.width
        val h = src.height
        val px = IntArray(w * h)
        src.getPixels(px, 0, w, 0, 0, w, h)
        val tmp = IntArray(w * h)
        repeat(passes) {
            for (y in 0 until h) blurLine(px, tmp, y * w, 1, w, radius)
            for (x in 0 until w) blurLine(tmp, px, x, w, h, radius)
        }
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        out.setPixels(px, 0, w, 0, 0, w, h)
        return out
    }

    /** Edge-clamped sliding-window box blur of one row/column. Output is opaque. */
    private fun blurLine(src: IntArray, dst: IntArray, start: Int, stride: Int, n: Int, r: Int) {
        val size = 2 * r + 1
        var sr = 0
        var sg = 0
        var sb = 0
        for (i in -r..r) {
            val p = src[start + clamp(i, n) * stride]
            sr += (p shr 16) and 0xFF
            sg += (p shr 8) and 0xFF
            sb += p and 0xFF
        }
        for (i in 0 until n) {
            dst[start + i * stride] =
                (0xFF shl 24) or ((sr / size) shl 16) or ((sg / size) shl 8) or (sb / size)
            val rem = src[start + clamp(i - r, n) * stride]
            val add = src[start + clamp(i + r + 1, n) * stride]
            sr += ((add shr 16) and 0xFF) - ((rem shr 16) and 0xFF)
            sg += ((add shr 8) and 0xFF) - ((rem shr 8) and 0xFF)
            sb += (add and 0xFF) - (rem and 0xFF)
        }
    }

    private fun clamp(i: Int, n: Int): Int = if (i < 0) 0 else if (i >= n) n - 1 else i
}
