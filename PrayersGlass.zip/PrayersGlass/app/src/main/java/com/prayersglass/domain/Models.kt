package com.prayersglass.domain

import java.time.LocalDate
import java.time.LocalTime

/** UI / widget language. */
enum class Lang(val tag: String) {
    AR("ar"),
    EN("en");

    val isRtl: Boolean get() = this == AR

    companion object {
        fun fromTag(tag: String?): Lang? = values().firstOrNull { it.tag == tag }
    }
}

/** The five daily prayers shown in widgets. */
enum class Prayer(val apiKey: String) {
    FAJR("Fajr"),
    DHUHR("Dhuhr"),
    ASR("Asr"),
    MAGHRIB("Maghrib"),
    ISHA("Isha");

    companion object {
        val ALL: List<Prayer> = values().toList()
    }
}

data class HijriDate(val day: Int, val monthAr: String, val monthEn: String, val year: Int)

/** Where a day's timings came from. */
enum class DataSource { ONLINE, LOCAL }

/** Wall-clock prayer times of one civil day at the user's location. */
data class DayTimes(
    val date: LocalDate,
    val times: Map<Prayer, LocalTime>,
    val hijri: HijriDate? = null,
    val source: DataSource = DataSource.ONLINE
) {
    fun time(p: Prayer): LocalTime = times.getValue(p)
}

/** Parameters that define a set of prayer timings (used as the cache key). */
data class CalcParams(
    val latitude: Double,
    val longitude: Double,
    /** Aladhan method id, or [CalcMethods.AUTO]. */
    val method: Int,
    /** 0 = standard Asr (Shafi'i, Maliki, Hanbali), 1 = Hanafi. */
    val school: Int
)
