package com.prayersglass.domain

/**
 * A prayer-time calculation convention.
 *
 * [id] matches the `method` parameter of the Aladhan API so the same choice drives both the
 * online source and the offline fallback calculator. [AUTO] omits the parameter and lets the
 * service pick the authority that matches the coordinates.
 */
data class CalcMethod(
    val id: Int,
    val nameAr: String,
    val nameEn: String,
    val fajrAngle: Double,
    val ishaAngle: Double,
    /** If > 0, Isha is this many minutes after Maghrib instead of using [ishaAngle]. */
    val ishaMinutes: Int = 0
)

object CalcMethods {
    const val AUTO: Int = -1

    val MWL = CalcMethod(3, "رابطة العالم الإسلامي", "Muslim World League", 18.0, 17.0)

    val ALL: List<CalcMethod> = listOf(
        CalcMethod(5, "الهيئة المصرية العامة للمساحة", "Egyptian General Authority of Survey", 19.5, 17.5),
        MWL,
        CalcMethod(4, "جامعة أم القرى (مكة المكرمة)", "Umm Al-Qura University, Makkah", 18.5, 0.0, 90),
        CalcMethod(1, "جامعة العلوم الإسلامية بكراتشي", "University of Islamic Sciences, Karachi", 18.0, 18.0),
        CalcMethod(2, "أمريكا الشمالية (ISNA)", "Islamic Society of North America", 15.0, 15.0),
        CalcMethod(8, "منطقة الخليج", "Gulf Region", 19.5, 0.0, 90),
        CalcMethod(9, "الكويت", "Kuwait", 18.0, 17.5),
        CalcMethod(10, "قطر", "Qatar", 18.0, 0.0, 90),
        CalcMethod(16, "دبي", "Dubai", 18.2, 18.2),
        CalcMethod(13, "رئاسة الشؤون الدينية التركية", "Diyanet, Turkey", 18.0, 17.0),
        CalcMethod(21, "المغرب", "Morocco", 19.0, 17.0),
        CalcMethod(19, "الجزائر", "Algeria", 18.0, 17.0),
        CalcMethod(18, "تونس", "Tunisia", 18.0, 18.0),
        CalcMethod(23, "الأردن", "Jordan", 18.0, 18.0),
        CalcMethod(11, "سنغافورة", "Singapore", 20.0, 18.0),
        CalcMethod(17, "ماليزيا (جاكيم)", "Malaysia (JAKIM)", 20.0, 18.0),
        CalcMethod(20, "إندونيسيا (كيمنَق)", "Indonesia (KEMENAG)", 20.0, 18.0)
    )

    fun byId(id: Int): CalcMethod? = ALL.firstOrNull { it.id == id }

    /** Method used by the offline calculator when the user left the choice on automatic. */
    fun forLocalCalculation(id: Int): CalcMethod = byId(id) ?: MWL

    fun displayName(id: Int, arabic: Boolean): String {
        if (id == AUTO) return if (arabic) "تلقائي (حسب موقعك)" else "Automatic (by your location)"
        val m = byId(id) ?: return if (arabic) "تلقائي (حسب موقعك)" else "Automatic (by your location)"
        return if (arabic) m.nameAr else m.nameEn
    }
}
