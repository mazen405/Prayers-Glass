package com.prayersglass.data

import android.content.Context
import android.content.SharedPreferences
import android.text.format.DateFormat
import com.prayersglass.domain.CalcMethods
import com.prayersglass.domain.Lang
import com.prayersglass.widget.Design
import com.prayersglass.widget.WidgetType
import org.json.JSONObject
import java.util.Locale

enum class LocationSource { AUTO, MANUAL, DEFAULT }

data class LocationInfo(
    val lat: Double,
    val lon: Double,
    /** Human readable place name; null when unknown (then coordinates are shown). */
    val name: String?,
    val source: LocationSource
) {
    companion object {
        /** Shown (and clearly labelled as a default) until the user shares or picks a location. */
        val CAIRO = LocationInfo(30.0444, 31.2357, null, LocationSource.DEFAULT)
    }
}

/** Per-widget appearance. Each placed widget owns one of these. */
data class WidgetConfig(
    val type: WidgetType,
    val lang: Lang,
    /** File name inside [BackgroundStore], or null for the built-in backdrop. */
    val bgFile: String?,
    /** Glass opacity in percent (40..100). */
    val opacity: Int,
    val showLocation: Boolean
) {
    fun toJson(): JSONObject = JSONObject()
        .put("type", type.id)
        .put("lang", lang.tag)
        .put("bg", bgFile ?: JSONObject.NULL)
        .put("opacity", opacity)
        .put("showLoc", showLocation)

    companion object {
        fun fromJson(o: JSONObject): WidgetConfig? {
            val type = WidgetType.fromId(o.optString("type")) ?: return null
            return WidgetConfig(
                type = type,
                lang = Lang.fromTag(o.optString("lang")) ?: Lang.AR,
                bgFile = if (o.isNull("bg")) null else o.optString("bg").ifEmpty { null },
                opacity = o.optInt("opacity", type.design.defaultOpacity).coerceIn(40, 100),
                showLocation = o.optBoolean("showLoc", true)
            )
        }

        fun default(type: WidgetType, lang: Lang) =
            WidgetConfig(type, lang, null, type.design.defaultOpacity, true)
    }
}

/** Typed wrapper around SharedPreferences. All state the app and its widgets share lives here. */
class SettingsStore private constructor(private val prefs: SharedPreferences) {

    companion object {
        private const val FILE = "prayers_glass_settings"
        private const val PENDING_TTL_MS = 10 * 60 * 1000L

        fun get(ctx: Context): SettingsStore =
            SettingsStore(ctx.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE))
    }

    // ---- global settings -------------------------------------------------------------------

    var appLang: Lang
        get() = Lang.fromTag(prefs.getString("app_lang", null))
            ?: if (Locale.getDefault().language == "ar") Lang.AR else Lang.EN
        set(v) = prefs.edit().putString("app_lang", v.tag).apply()

    /** Aladhan method id or [CalcMethods.AUTO]. */
    var method: Int
        get() = prefs.getInt("method", CalcMethods.AUTO)
        set(v) = prefs.edit().putInt("method", v).apply()

    /** 0 = standard Asr, 1 = Hanafi. */
    var school: Int
        get() = prefs.getInt("school", 0)
        set(v) = prefs.edit().putInt("school", v).apply()

    /** -1 = follow the device, 0 = 12-hour, 1 = 24-hour. */
    var clockMode: Int
        get() = prefs.getInt("clock_mode", -1)
        set(v) = prefs.edit().putInt("clock_mode", v).apply()

    fun is24h(ctx: Context): Boolean = when (clockMode) {
        1 -> true
        0 -> false
        else -> DateFormat.is24HourFormat(ctx)
    }

    var location: LocationInfo
        get() {
            val lat = prefs.getString("loc_lat", null)?.toDoubleOrNull()
            val lon = prefs.getString("loc_lon", null)?.toDoubleOrNull()
            if (lat == null || lon == null) return LocationInfo.CAIRO
            val src = runCatching { LocationSource.valueOf(prefs.getString("loc_src", "") ?: "") }
                .getOrDefault(LocationSource.MANUAL)
            return LocationInfo(lat, lon, prefs.getString("loc_name", null), src)
        }
        set(v) {
            prefs.edit()
                .putString("loc_lat", v.lat.toString())
                .putString("loc_lon", v.lon.toString())
                .putString("loc_name", v.name)
                .putString("loc_src", v.source.name)
                .apply()
        }

    var askedLocation: Boolean
        get() = prefs.getBoolean("asked_location", false)
        set(v) = prefs.edit().putBoolean("asked_location", v).apply()

    // ---- sync status -----------------------------------------------------------------------

    var lastSyncMs: Long
        get() = prefs.getLong("last_sync_ms", 0L)
        set(v) = prefs.edit().putLong("last_sync_ms", v).apply()

    var lastAttemptMs: Long
        get() = prefs.getLong("last_attempt_ms", 0L)
        set(v) = prefs.edit().putLong("last_attempt_ms", v).apply()

    /** [ApiException.Kind] name of the most recent failure, or null if the last sync succeeded. */
    var lastError: String?
        get() = prefs.getString("last_error", null)
        set(v) = prefs.edit().putString("last_error", v).apply()

    // ---- designer draft (what the gallery is currently editing) ------------------------------

    var draft: WidgetConfig
        get() {
            val raw = prefs.getString("draft", null)
            val parsed = raw?.let { runCatching { WidgetConfig.fromJson(JSONObject(it)) }.getOrNull() }
            return parsed ?: WidgetConfig.default(WidgetType.LIQUID_GLASS_4X2, appLang)
        }
        set(v) = prefs.edit().putString("draft", v.toJson().toString()).apply()

    // ---- per widget ------------------------------------------------------------------------

    fun widgetConfig(id: Int): WidgetConfig? {
        val raw = prefs.getString("w_$id", null) ?: return null
        return runCatching { WidgetConfig.fromJson(JSONObject(raw)) }.getOrNull()
    }

    fun saveWidgetConfig(id: Int, cfg: WidgetConfig) {
        prefs.edit().putString("w_$id", cfg.toJson().toString()).apply()
    }

    fun removeWidget(id: Int) {
        prefs.edit().remove("w_$id").remove("full_$id").apply()
    }

    /** Whether a complete RemoteViews (with background) was already delivered for this widget. */
    fun isFullyRendered(id: Int): Boolean = prefs.getBoolean("full_$id", false)

    fun setFullyRendered(id: Int, v: Boolean) {
        prefs.edit().putBoolean("full_$id", v).apply()
    }

    /** All background file names still referenced by any widget, the draft or a pending pin. */
    fun referencedBackgrounds(): Set<String> {
        val out = HashSet<String>()
        for ((key, value) in prefs.all) {
            if (value !is String) continue
            if (key.startsWith("w_") || key == "draft" || key == "pending") {
                runCatching { JSONObject(value) }.getOrNull()?.let { o ->
                    if (!o.isNull("bg")) o.optString("bg").takeIf { it.isNotEmpty() }?.let(out::add)
                }
            }
        }
        return out
    }

    // ---- pending pin -----------------------------------------------------------------------
    // requestPinAppWidget() cannot carry data, and the new widget id is unknown until the launcher
    // has placed it. We therefore remember the configuration the user just designed and hand it to
    // the next widget of that type that appears.

    fun setPending(cfg: WidgetConfig) {
        prefs.edit()
            .putString("pending", cfg.toJson().put("ts", System.currentTimeMillis()).toString())
            .apply()
    }

    fun claimPending(type: WidgetType, nowMs: Long = System.currentTimeMillis()): WidgetConfig? {
        val raw = prefs.getString("pending", null) ?: return null
        val o = runCatching { JSONObject(raw) }.getOrNull() ?: return null
        if (nowMs - o.optLong("ts", 0L) > PENDING_TTL_MS) {
            prefs.edit().remove("pending").apply()
            return null
        }
        val cfg = WidgetConfig.fromJson(o) ?: return null
        if (cfg.type != type) return null
        prefs.edit().remove("pending").apply()
        return cfg
    }

    fun defaultDesignOpacity(d: Design): Int = d.defaultOpacity
}
