package com.prayersglass.widget

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.text.TextUtils
import android.view.View
import android.widget.RemoteViews
import com.prayersglass.R
import com.prayersglass.data.PrayerData
import com.prayersglass.data.SettingsStore
import com.prayersglass.data.WidgetConfig
import com.prayersglass.glass.GlassRenderer
import com.prayersglass.glass.RingRenderer
import com.prayersglass.ui.MainActivity
import com.prayersglass.util.LocaleUtil
import java.time.Instant
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

data class SizeDp(val w: Int, val h: Int)

/**
 * Turns a [WidgetConfig] + prayer data into a [RemoteViews]. The very same function feeds the real
 * home-screen widget and the in-app preview, so what users see in the gallery is what they get.
 */
object WidgetRenderer {

    enum class Mode {
        /** Background bitmap, direction, click handling and all text. */
        FULL,
        /** Only the changing text/rings; merged into the last FULL update (cheap for minute ticks). */
        TEXT
    }

    private const val WHITE = 0xFFFFFFFF.toInt()
    private const val DIM = 0x8FFFFFFF.toInt()

    private val CELL = intArrayOf(R.id.c0, R.id.c1, R.id.c2, R.id.c3, R.id.c4)
    private val NAME = intArrayOf(R.id.n0, R.id.n1, R.id.n2, R.id.n3, R.id.n4)
    private val TIME = intArrayOf(R.id.t0, R.id.t1, R.id.t2, R.id.t3, R.id.t4)
    private val RING = intArrayOf(R.id.ring0, R.id.ring1, R.id.ring2, R.id.ring3, R.id.ring4)
    private val DOT = intArrayOf(R.id.d0, R.id.d1, R.id.d2, R.id.d3, R.id.d4)

    fun build(
        ctx: Context,
        type: WidgetType,
        cfg: WidgetConfig,
        data: PrayerData?,
        now: Instant,
        size: SizeDp,
        mode: Mode,
        forPreview: Boolean
    ): RemoteViews {
        val settings = SettingsStore.get(ctx)
        val lc = LocaleUtil.wrap(ctx, cfg.lang)
        val model = ModelBuilder.build(lc, cfg, data, settings, now, settings.is24h(ctx))
        val rv = RemoteViews(ctx.packageName, type.layoutRes)

        if (mode == Mode.FULL) {
            applyDirection(rv, cfg, forPreview)
            applyBackground(ctx, rv, type, cfg, size)
            if (!forPreview) {
                val intent = Intent(ctx, MainActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                val pi = PendingIntent.getActivity(
                    ctx, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                rv.setOnClickPendingIntent(R.id.root, pi)
            }
        }

        if (model.status != Status.OK) {
            rv.setViewVisibility(R.id.content, View.GONE)
            rv.setViewVisibility(R.id.tv_status, View.VISIBLE)
            rv.setTextViewText(R.id.tv_status, model.statusMessage)
            return rv
        }
        rv.setViewVisibility(R.id.content, View.VISIBLE)
        rv.setViewVisibility(R.id.tv_status, View.GONE)

        val density = ctx.resources.displayMetrics.density
        when (type) {
            WidgetType.LIQUID_GLASS_4X2 -> {
                text(rv, R.id.tv_label, model.label)
                text(rv, R.id.tv_location, model.locationLine)
                text(rv, R.id.tv_headline, model.headline)
                text(rv, R.id.tv_time, model.time)
                text(rv, R.id.tv_ampm, model.ampm)
                text(rv, R.id.tv_countdown, model.countdown)
                bindCells(rv, model)
            }
            WidgetType.NEXT_PRAYER_2X2 -> {
                text(rv, R.id.tv_headline, model.headline)
                text(rv, R.id.tv_time, model.timeWithMeridiem)
                text(rv, R.id.tv_big, model.bigCountdown)
                text(rv, R.id.tv_countdown, model.countdown)
            }
            WidgetType.NEXT_PRAYER_4X1 -> {
                text(rv, R.id.tv_headline, model.headline)
                text(rv, R.id.tv_time, model.timeWithMeridiem)
                text(rv, R.id.tv_countdown, model.countdown)
                text(rv, R.id.tv_big, model.bigCountdown)
            }
            WidgetType.PRAYER_STRIP_4X1 -> bindCells(rv, model)
            WidgetType.PRAYER_CIRCLES_4X2 -> {
                text(rv, R.id.tv_headline, model.headline)
                text(rv, R.id.tv_countdown, model.countdown)
                text(rv, R.id.tv_location, model.locationLine)
                val ringPx = min(220, max(48, (RING_DP * density).toInt()))
                model.rows.forEachIndexed { i, row ->
                    rv.setTextViewText(NAME[i], row.name)
                    rv.setTextViewText(TIME[i], row.time)
                    val dim = row.state == RowState.PASSED
                    rv.setTextColor(NAME[i], if (dim) DIM else WHITE)
                    rv.setTextColor(TIME[i], if (dim) DIM else WHITE)
                    val st = when (row.state) {
                        RowState.PASSED -> RingRenderer.State.PASSED
                        RowState.UPCOMING -> RingRenderer.State.UPCOMING
                        RowState.NEXT -> RingRenderer.State.NEXT
                        RowState.CURRENT -> RingRenderer.State.CURRENT
                    }
                    rv.setImageViewBitmap(RING[i], RingRenderer.render(ringPx, st, model.progress))
                }
            }
            WidgetType.MINIMAL_GLASS_2X2 -> {
                text(rv, R.id.tv_headline, model.headline)
                text(rv, R.id.tv_time, model.time)
                text(rv, R.id.tv_ampm, model.ampm)
                text(rv, R.id.tv_countdown, model.countdown)
                model.rows.forEachIndexed { i, row ->
                    rv.setImageViewResource(
                        DOT[i],
                        when (row.state) {
                            RowState.PASSED -> R.drawable.dot_passed
                            RowState.UPCOMING -> R.drawable.dot_future
                            RowState.NEXT, RowState.CURRENT -> R.drawable.dot_next
                        }
                    )
                }
            }
            WidgetType.MINIMAL_GLASS_4X1 -> {
                text(rv, R.id.tv_headline, model.headline)
                text(rv, R.id.tv_time, model.timeWithMeridiem)
                text(rv, R.id.tv_countdown, model.countdown)
            }
        }
        return rv
    }

    private const val RING_DP = 44

    private fun text(rv: RemoteViews, id: Int, value: String?) {
        if (value.isNullOrEmpty()) {
            rv.setViewVisibility(id, View.GONE)
        } else {
            rv.setViewVisibility(id, View.VISIBLE)
            rv.setTextViewText(id, value)
        }
    }

    private fun bindCells(rv: RemoteViews, model: WidgetModel) {
        model.rows.forEachIndexed { i, row ->
            rv.setTextViewText(NAME[i], row.name)
            rv.setTextViewText(TIME[i], row.time)
            val highlighted = row.state == RowState.NEXT || row.state == RowState.CURRENT
            val dim = row.state == RowState.PASSED
            rv.setInt(
                CELL[i], "setBackgroundResource",
                if (highlighted) R.drawable.glass_panel_active else R.drawable.glass_panel
            )
            rv.setTextColor(NAME[i], if (dim) DIM else WHITE)
            rv.setTextColor(TIME[i], if (dim) DIM else WHITE)
        }
    }

    private fun applyDirection(rv: RemoteViews, cfg: WidgetConfig, force: Boolean) {
        val deviceRtl =
            TextUtils.getLayoutDirectionFromLocale(Locale.getDefault()) == View.LAYOUT_DIRECTION_RTL
        if (force || deviceRtl != cfg.lang.isRtl) {
            rv.setInt(
                R.id.root, "setLayoutDirection",
                if (cfg.lang.isRtl) View.LAYOUT_DIRECTION_RTL else View.LAYOUT_DIRECTION_LTR
            )
        }
    }

    private fun applyBackground(ctx: Context, rv: RemoteViews, type: WidgetType, cfg: WidgetConfig, size: SizeDp) {
        val density = ctx.resources.displayMetrics.density
        val wPx = size.w * density
        val hPx = size.h * density
        // Keep the bitmap comfortably below the RemoteViews binder budget.
        val k = min(1f, 1000f / max(wPx, hPx))
        val bmp = GlassRenderer.render(
            ctx, (wPx * k).toInt(), (hPx * k).toInt(), density * k, cfg.bgFile, type.design
        )
        rv.setImageViewBitmap(R.id.bg, bmp)
        rv.setInt(R.id.bg, "setImageAlpha", (cfg.opacity.coerceIn(0, 100) * 255) / 100)
    }
}
