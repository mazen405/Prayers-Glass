package com.prayersglass.domain

import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId
import java.time.ZonedDateTime
import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.asin
import kotlin.math.atan
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.sin
import kotlin.math.tan

/**
 * Offline prayer-time calculator (classic solar-angle algorithm).
 *
 * It is only a *fallback* used when the online source has not been reachable yet. Results can
 * differ by a few minutes from official timetables, and the UI labels them as locally computed.
 */
object PrayerCalculator {

    private const val SUN_ANGLE = 0.833 // sunrise/sunset: refraction + solar radius

    private fun rad(d: Double): Double = Math.toRadians(d)
    private fun deg(r: Double): Double = Math.toDegrees(r)
    private fun fix(a: Double, mod: Double): Double = a - mod * floor(a / mod)
    private fun fixAngle(a: Double): Double = fix(a, 360.0)
    private fun fixHour(a: Double): Double = fix(a, 24.0)

    private fun julian(year: Int, month: Int, day: Int): Double {
        var y = year
        var m = month
        if (m <= 2) {
            y -= 1
            m += 12
        }
        val a = floor(y / 100.0)
        val b = 2 - a + floor(a / 4.0)
        return floor(365.25 * (y + 4716)) + floor(30.6001 * (m + 1)) + day + b - 1524.5
    }

    /** @return declination (degrees) and equation of time (hours) for a Julian date. */
    private fun sunPosition(jd: Double): Pair<Double, Double> {
        val d = jd - 2451545.0
        val g = fixAngle(357.529 + 0.98560028 * d)
        val q = fixAngle(280.459 + 0.98564736 * d)
        val l = fixAngle(q + 1.915 * sin(rad(g)) + 0.020 * sin(rad(2 * g)))
        val e = 23.439 - 0.00000036 * d
        val ra = deg(atan2(cos(rad(e)) * sin(rad(l)), cos(rad(l)))) / 15.0
        val eqt = q / 15.0 - fixHour(ra)
        val decl = deg(asin(sin(rad(e)) * sin(rad(l))))
        return Pair(decl, eqt)
    }

    private class Raw(
        val fajr: Double,
        val sunrise: Double,
        val dhuhr: Double,
        val asr: Double,
        val sunset: Double,
        val isha: Double
    )

    private fun pass(
        jd: Double,
        lat: Double,
        fajrAngle: Double,
        ishaAngle: Double,
        asrFactor: Double,
        portions: DoubleArray // fajr, sunrise, dhuhr, asr, sunset, isha as fractions of a day
    ): Raw {
        fun midDay(t: Double): Double = fixHour(12.0 - sunPosition(jd + t).second)

        fun angleTime(angle: Double, t: Double, ccw: Boolean): Double {
            val decl = sunPosition(jd + t).first
            val noon = midDay(t)
            val v = (-sin(rad(angle)) - sin(rad(decl)) * sin(rad(lat))) /
                (cos(rad(decl)) * cos(rad(lat)))
            if (v < -1.0 || v > 1.0) return Double.NaN
            val h = deg(acos(v)) / 15.0
            return if (ccw) noon - h else noon + h
        }

        fun asrTime(factor: Double, t: Double): Double {
            val decl = sunPosition(jd + t).first
            val angle = -deg(atan(1.0 / (factor + tan(rad(abs(lat - decl))))))
            return angleTime(angle, t, false)
        }

        return Raw(
            fajr = angleTime(fajrAngle, portions[0], true),
            sunrise = angleTime(SUN_ANGLE, portions[1], true),
            dhuhr = midDay(portions[2]),
            asr = asrTime(asrFactor, portions[3]),
            sunset = angleTime(SUN_ANGLE, portions[4], false),
            isha = angleTime(ishaAngle, portions[5], false)
        )
    }

    private fun timeDiff(a: Double, b: Double): Double = fixHour(b - a)

    /**
     * @param school 0 = Shafi'i/Maliki/Hanbali (standard Asr), 1 = Hanafi.
     * @throws IllegalStateException when the sun never reaches the required angle and no
     *         high-latitude fallback is possible.
     */
    fun compute(
        date: LocalDate,
        lat: Double,
        lon: Double,
        zone: ZoneId,
        method: CalcMethod,
        school: Int
    ): DayTimes {
        val jd = julian(date.year, date.monthValue, date.dayOfMonth) - lon / (15.0 * 24.0)
        val asrFactor = if (school == 1) 2.0 else 1.0
        val ishaAngle = if (method.ishaMinutes > 0) 0.0 else method.ishaAngle

        var portions = doubleArrayOf(5.0 / 24, 6.0 / 24, 12.0 / 24, 13.0 / 24, 18.0 / 24, 18.0 / 24)
        var raw = pass(jd, lat, method.fajrAngle, ishaAngle, asrFactor, portions)
        // Second pass: re-evaluate the sun position at the times found by the first pass.
        fun refine(r: Raw, fallback: DoubleArray): DoubleArray = doubleArrayOf(
            if (r.fajr.isNaN()) fallback[0] else r.fajr / 24.0,
            if (r.sunrise.isNaN()) fallback[1] else r.sunrise / 24.0,
            if (r.dhuhr.isNaN()) fallback[2] else r.dhuhr / 24.0,
            if (r.asr.isNaN()) fallback[3] else r.asr / 24.0,
            if (r.sunset.isNaN()) fallback[4] else r.sunset / 24.0,
            if (r.isha.isNaN()) fallback[5] else r.isha / 24.0
        )
        portions = refine(raw, portions)
        raw = pass(jd, lat, method.fajrAngle, ishaAngle, asrFactor, portions)

        val offsetHours = ZonedDateTime.of(date, LocalTime.NOON, zone).offset.totalSeconds / 3600.0
        val shift = offsetHours - lon / 15.0

        var fajr = raw.fajr + shift
        val sunrise = raw.sunrise + shift
        val dhuhr = raw.dhuhr + shift
        val asr = raw.asr + shift
        val sunset = raw.sunset + shift
        val maghrib = sunset
        var isha = if (method.ishaMinutes > 0) maghrib + method.ishaMinutes / 60.0 else raw.isha + shift

        // High-latitude fallback ("middle of the night") when angles are unreachable or absurd.
        if (!sunrise.isNaN() && !sunset.isNaN()) {
            val night = timeDiff(sunset, sunrise)
            if (fajr.isNaN() || timeDiff(fajr, sunrise) > night / 2.0) fajr = sunrise - night / 2.0
            if (isha.isNaN() || timeDiff(sunset, isha) > night / 2.0) isha = sunset + night / 2.0
        }

        val all = listOf(fajr, sunrise, dhuhr, asr, maghrib, isha)
        check(all.none { it.isNaN() }) { "No solution for this latitude/date" }

        fun toTime(hours: Double): LocalTime {
            val minutes = Math.round(fixHour(hours) * 60.0).toInt() % (24 * 60)
            return LocalTime.of(minutes / 60, minutes % 60)
        }

        return DayTimes(
            date = date,
            times = mapOf(
                Prayer.FAJR to toTime(fajr),
                Prayer.DHUHR to toTime(dhuhr),
                Prayer.ASR to toTime(asr),
                Prayer.MAGHRIB to toTime(maghrib),
                Prayer.ISHA to toTime(isha)
            ),
            source = DataSource.LOCAL
        )
    }
}
