package com.prayersglass.domain

import java.time.Duration
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZonedDateTime

data class PrayerInstant(val prayer: Prayer, val time: ZonedDateTime, val approximate: Boolean = false)

/** Everything a widget needs to know about "now". */
data class PrayerSnapshot(
    val zone: ZoneId,
    val date: LocalDate,
    /** The five prayers of the current civil day, in order. */
    val today: List<PrayerInstant>,
    /** The most recent prayer that has already started (may belong to yesterday). */
    val previous: PrayerInstant,
    /** The next prayer (may belong to tomorrow). */
    val next: PrayerInstant,
    /** True during the first [PrayerEngine.JUST_ENTERED_MINUTES] minutes of a prayer. */
    val justEntered: Boolean,
    val hijri: HijriDate?,
    val source: DataSource
) {
    fun remainingSeconds(now: Instant): Long =
        maxOf(0L, Duration.between(now, next.time.toInstant()).seconds)

    /** 0..1 progress between [previous] and [next]. */
    fun progress(now: Instant): Float {
        val total = Duration.between(previous.time, next.time).toMillis().toFloat()
        if (total <= 0f) return 0f
        val done = Duration.between(previous.time.toInstant(), now).toMillis().toFloat()
        return (done / total).coerceIn(0f, 1f)
    }

    /** Next moment at which what we display changes by itself (next prayer or end of "just entered"). */
    fun nextBoundary(): Instant {
        val nextAt = next.time.toInstant()
        if (!justEntered) return nextAt
        val endOfBanner = previous.time.plusMinutes(PrayerEngine.JUST_ENTERED_MINUTES).toInstant()
        return if (endOfBanner.isBefore(nextAt)) endOfBanner else nextAt
    }
}

/**
 * Pure logic that answers "which prayer is next?". Handles day rollover and daylight saving time
 * through java.time zone rules.
 */
object PrayerEngine {
    const val JUST_ENTERED_MINUTES = 20L


    fun snapshot(days: Map<LocalDate, DayTimes>, zone: ZoneId, now: Instant): PrayerSnapshot? {
        val today = now.atZone(zone).toLocalDate()
        val todayTimes = days[today] ?: return null
        if (Prayer.ALL.any { todayTimes.times[it] == null }) return null

        fun instants(d: LocalDate, t: DayTimes, shiftDays: Long, approximate: Boolean): List<PrayerInstant> =
            Prayer.ALL.map { p ->
                val z = ZonedDateTime.of(d, t.time(p), zone).plusDays(shiftDays)
                PrayerInstant(p, z, approximate)
            }

        val todayList = instants(today, todayTimes, 0, false)
        val yesterday = today.minusDays(1)
        val tomorrow = today.plusDays(1)
        val yList = days[yesterday]?.let { instants(yesterday, it, 0, false) }
            ?: instants(today, todayTimes, -1, true)
        val tList = days[tomorrow]?.let { instants(tomorrow, it, 0, false) }
            ?: instants(today, todayTimes, 1, true)

        val all = (yList + todayList + tList).sortedBy { it.time.toInstant() }
        val next = all.firstOrNull { it.time.toInstant().isAfter(now) } ?: return null
        val previous = all.lastOrNull { !it.time.toInstant().isAfter(now) } ?: return null
        val sinceMinutes = Duration.between(previous.time.toInstant(), now).toMinutes()
        return PrayerSnapshot(
            zone = zone,
            date = today,
            today = todayList,
            previous = previous,
            next = next,
            justEntered = sinceMinutes < JUST_ENTERED_MINUTES,
            hijri = todayTimes.hijri,
            source = todayTimes.source
        )
    }
}
