package com.prayersglass.ui

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.text.format.DateUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import com.prayersglass.R
import com.prayersglass.data.ApiException
import com.prayersglass.data.LocationInfo
import com.prayersglass.data.LocationSource
import com.prayersglass.data.PrayerData
import com.prayersglass.data.SettingsStore
import com.prayersglass.data.Syncer
import com.prayersglass.data.TimesRepository
import com.prayersglass.data.WidgetConfig
import com.prayersglass.domain.CalcMethods
import com.prayersglass.domain.CalcParams
import com.prayersglass.domain.Lang
import com.prayersglass.domain.PrayerEngine
import com.prayersglass.domain.TimeFormatter
import com.prayersglass.glass.BackgroundStore
import com.prayersglass.glass.GlassRenderer
import com.prayersglass.util.LocaleUtil
import com.prayersglass.util.LocateResult
import com.prayersglass.util.LocationHelper
import com.prayersglass.util.dpInt
import com.prayersglass.widget.Design
import com.prayersglass.widget.ModelBuilder
import com.prayersglass.widget.PinHelper
import com.prayersglass.widget.SizeDp
import com.prayersglass.widget.WidgetRenderer
import com.prayersglass.widget.WidgetType
import com.prayersglass.widget.WidgetUpdater
import java.time.Instant
import java.util.concurrent.Executors

/**
 * The single screen of the app: browse designs with live previews, pick size / photo / language,
 * then ask the launcher to pin the widget. Every preview is produced by the same renderer that
 * draws the real widgets.
 */
class MainActivity : Activity() {

    private lateinit var store: SettingsStore
    private lateinit var draft: WidgetConfig
    private val main = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()
    private var busy = false
    private var updatingControls = false

    override fun attachBaseContext(base: Context) {
        super.attachBaseContext(LocaleUtil.wrap(base, SettingsStore.get(base).appLang))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = SettingsStore.get(this)
        draft = store.draft
        setContentView(R.layout.activity_main)
        applyInsets()
        wireListeners()
        renderAll()
        maybeAskLocationFirstRun()
    }

    override fun onResume() {
        super.onResume()
        draft = store.draft
        renderAll()
        io.execute {
            // Make sure widgets are fresh and, if there is no online data yet, fetch it.
            val loc = store.location
            val has = TimesRepository.hasOnlineData(
                applicationContext,
                CalcParams(loc.lat, loc.lon, store.method, store.school),
                java.time.LocalDate.now()
            )
            if (!has) {
                try { Syncer.sync(applicationContext, false) } catch (e: Exception) { }
            } else {
                WidgetUpdater.updateAll(applicationContext, WidgetRenderer.Mode.FULL)
            }
            main.post { if (!isDestroyed) renderStatus() }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        main.removeCallbacksAndMessages(null)
        io.shutdown()
    }

    // ---------------------------------------------------------------------------------------
    // Setup
    // ---------------------------------------------------------------------------------------

    @Suppress("DEPRECATION")
    private fun applyInsets() {
        val scroll = findViewById<ScrollView>(R.id.scroll)
        if (Build.VERSION.SDK_INT >= 30) {
            window.setDecorFitsSystemWindows(false)
        } else {
            window.decorView.systemUiVisibility =
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                    View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                    View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        }
        scroll.setOnApplyWindowInsetsListener { v, insets ->
            val top: Int
            val bottom: Int
            if (Build.VERSION.SDK_INT >= 30) {
                val bars = insets.getInsets(WindowInsets.Type.systemBars())
                top = bars.top
                bottom = bars.bottom
            } else {
                top = insets.systemWindowInsetTop
                bottom = insets.systemWindowInsetBottom
            }
            v.setPadding(0, top, 0, bottom)
            insets
        }
    }

    private fun wireListeners() {
        find<TextView>(R.id.btn_app_lang).setOnClickListener {
            store.appLang = if (store.appLang == Lang.AR) Lang.EN else Lang.AR
            recreate()
        }
        find<View>(R.id.btn_locate).setOnClickListener { onLocateClicked() }
        find<View>(R.id.btn_city).setOnClickListener { showCitySearch() }
        find<View>(R.id.btn_refresh).setOnClickListener { syncTimes(force = true) }
        find<View>(R.id.btn_pick_image).setOnClickListener { pickImage() }
        find<View>(R.id.btn_default_bg).setOnClickListener {
            updateDraft(draft.copy(bgFile = null))
            BackgroundStore.cleanup(this, store.referencedBackgrounds())
            renderAll()
        }
        find<View>(R.id.chip_wlang_ar).setOnClickListener { updateDraft(draft.copy(lang = Lang.AR)); renderAll() }
        find<View>(R.id.chip_wlang_en).setOnClickListener { updateDraft(draft.copy(lang = Lang.EN)); renderAll() }
        find<View>(R.id.chip_show_location).setOnClickListener {
            updateDraft(draft.copy(showLocation = !draft.showLocation)); renderAll()
        }
        find<View>(R.id.chip_24h).setOnClickListener {
            store.clockMode = if (store.is24h(this)) 0 else 1
            refreshWidgetsAsync()
            renderAll()
        }
        find<View>(R.id.chip_school_standard).setOnClickListener { setSchool(0) }
        find<View>(R.id.chip_school_hanafi).setOnClickListener { setSchool(1) }
        find<View>(R.id.btn_method).setOnClickListener { showMethodDialog() }
        find<View>(R.id.btn_add).setOnClickListener { addToHomeScreen() }

        find<SeekBar>(R.id.seek_opacity).setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, progress: Int, fromUser: Boolean) {
                if (updatingControls || !fromUser) return
                draft = draft.copy(opacity = 40 + progress)
                find<TextView>(R.id.tv_opacity).text = getString(R.string.label_opacity, draft.opacity)
                renderPreview()
            }

            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) {
                store.draft = draft
                renderDesigns()
            }
        })
    }

    private fun <T : View> find(id: Int): T = findViewById(id)

    private fun updateDraft(new: WidgetConfig) {
        draft = new
        store.draft = new
    }

    // ---------------------------------------------------------------------------------------
    // Rendering
    // ---------------------------------------------------------------------------------------

    private fun renderAll() {
        renderPageBackground()
        renderStatus()
        renderDesigns()
        renderSizeChips()
        renderPreview()
        syncControls()
        renderMyWidgets()
    }

    private fun renderPageBackground() {
        val dm = resources.displayMetrics
        val k = 0.3f
        val bmp = GlassRenderer.renderPage(
            this, (dm.widthPixels * k).toInt(), (dm.heightPixels * k).toInt(), draft.bgFile
        )
        find<ImageView>(R.id.app_bg).setImageBitmap(bmp)
    }

    private fun previewData(): PrayerData {
        val now = Instant.now()
        return TimesRepository.load(this, store, now) ?: TimesRepository.demo(store.location, now)
    }

    private fun availableWidthDp(): Int {
        val dm = resources.displayMetrics
        return (dm.widthPixels / dm.density).toInt() - 2 * 16 - 2 * 16
    }

    /** Inflates the real RemoteViews for [type] into [host]. */
    private fun showPreview(host: FrameLayout, type: WidgetType, cfg: WidgetConfig, data: PrayerData, maxWidthDp: Int) {
        host.removeAllViews()
        val w = minOf(type.previewWidthDp, maxWidthDp)
        val h = type.previewHeightDp
        try {
            val rv = WidgetRenderer.build(this, type, cfg, data, Instant.now(), SizeDp(w, h), WidgetRenderer.Mode.FULL, true)
            val view = rv.apply(this, host)
            host.addView(view, FrameLayout.LayoutParams(dpInt(w), dpInt(h), Gravity.CENTER_HORIZONTAL))
        } catch (e: Exception) {
            host.addView(TextView(this).apply {
                text = e.javaClass.simpleName
                setTextColor(getColor(R.color.warning))
            })
        }
    }

    private fun renderPreview() {
        val data = previewData()
        find<View>(R.id.tv_demo_note).visibility = if (data.isDemo) View.VISIBLE else View.GONE
        showPreview(find(R.id.preview_host), draft.type, draft, data, availableWidthDp())
    }

    private fun renderDesigns() {
        val list = find<LinearLayout>(R.id.design_list)
        list.removeAllViews()
        val data = previewData()
        val selected = draft.type.design
        for (d in Design.values()) {
            val isSel = d == selected
            val type = if (isSel) draft.type else WidgetType.forDesign(d).first()
            val cfg = if (isSel) draft else draft.copy(type = type, opacity = d.defaultOpacity)
            val pw = minOf(type.previewWidthDp, 340)

            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setBackgroundResource(if (isSel) R.drawable.bg_card_selected else R.drawable.bg_card)
                setPadding(dpInt(12), dpInt(12), dpInt(12), dpInt(12))
                isClickable = true
                isFocusable = true
                setOnClickListener { selectDesign(d) }
            }
            val host = FrameLayout(this)
            card.addView(host, LinearLayout.LayoutParams(dpInt(pw), dpInt(type.previewHeightDp)))
            showPreview(host, type, cfg, data, pw)

            val titleRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            titleRow.addView(textView(R.style.Text, 15f, bold = true).apply { setText(d.nameRes) })
            if (isSel) {
                titleRow.addView(textView(R.style.Text_Caption, 12f).apply {
                    setText(R.string.badge_favorite)
                    setTextColor(getColor(R.color.accent))
                    setPadding(dpInt(8), 0, 0, 0)
                })
            }
            card.addView(titleRow, LinearLayout.LayoutParams(dpInt(pw), ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dpInt(10) })
            card.addView(textView(R.style.Text_Caption, 12f).apply { setText(d.descRes) },
                LinearLayout.LayoutParams(dpInt(pw), ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dpInt(2) })

            list.addView(card, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                marginEnd = dpInt(12)
            })
        }
    }

    private fun textView(style: Int, sizeSp: Float, bold: Boolean = false): TextView =
        TextView(this, null, 0, style).apply {
            textSize = sizeSp
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    private fun selectDesign(d: Design) {
        if (d == draft.type.design) return
        val old = draft.type.design
        val newType = WidgetType.forDesign(d).first()
        val opacity = if (draft.opacity == old.defaultOpacity) d.defaultOpacity else draft.opacity
        updateDraft(draft.copy(type = newType, opacity = opacity))
        renderAll()
    }

    private fun renderSizeChips() {
        val box = find<LinearLayout>(R.id.size_chips)
        box.removeAllViews()
        for (t in WidgetType.forDesign(draft.type.design)) {
            val chip = TextView(this, null, 0, R.style.Chip).apply {
                text = t.sizeLabel
                isSelected = t == draft.type
                setOnClickListener {
                    updateDraft(draft.copy(type = t))
                    renderAll()
                }
            }
            box.addView(chip, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                marginEnd = dpInt(8)
            })
        }
    }

    private fun syncControls() {
        updatingControls = true
        find<TextView>(R.id.btn_app_lang).text = if (store.appLang == Lang.AR) "English" else "العربية"
        find<View>(R.id.chip_wlang_ar).isSelected = draft.lang == Lang.AR
        find<View>(R.id.chip_wlang_en).isSelected = draft.lang == Lang.EN
        find<View>(R.id.chip_show_location).isSelected = draft.showLocation
        find<View>(R.id.chip_24h).isSelected = store.is24h(this)
        find<View>(R.id.chip_school_standard).isSelected = store.school == 0
        find<View>(R.id.chip_school_hanafi).isSelected = store.school == 1
        find<TextView>(R.id.tv_opacity).text = getString(R.string.label_opacity, draft.opacity)
        find<SeekBar>(R.id.seek_opacity).progress = (draft.opacity - 40).coerceIn(0, 60)
        find<TextView>(R.id.btn_method).text = getString(
            R.string.method_label, CalcMethods.displayName(store.method, store.appLang == Lang.AR)
        )
        updatingControls = false
    }

    private fun renderStatus() {
        val loc = store.location
        val now = Instant.now()
        val data = TimesRepository.load(this, store, now)
        find<TextView>(R.id.tv_location).text = ModelBuilder.locationText(this, loc)

        val nextLine = data?.let { PrayerEngine.snapshot(it.days, it.zone, now) }?.let { snap ->
            getString(
                R.string.next_line,
                ModelBuilder.prayerName(this, snap.next.prayer),
                TimeFormatter.full(snap.next.time.toLocalTime(), store.appLang, store.is24h(this))
            )
        }
        find<TextView>(R.id.tv_next_line).apply {
            text = nextLine ?: ""
            visibility = if (nextLine == null) View.GONE else View.VISIBLE
        }

        val notices = ArrayList<String>()
        if (loc.source == LocationSource.DEFAULT) notices.add(getString(R.string.loc_notice_default))
        if (data != null && data.source == com.prayersglass.domain.DataSource.LOCAL) {
            notices.add(getString(R.string.source_local_note))
        }
        find<TextView>(R.id.tv_notice).apply {
            text = notices.joinToString("\n\n")
            visibility = if (notices.isEmpty()) View.GONE else View.VISIBLE
        }

        val last = store.lastSyncMs
        find<TextView>(R.id.tv_sync).text = if (last > 0) {
            getString(
                R.string.sync_line,
                DateUtils.formatDateTime(
                    this, last,
                    DateUtils.FORMAT_SHOW_TIME or DateUtils.FORMAT_SHOW_DATE or DateUtils.FORMAT_ABBREV_MONTH
                )
            )
        } else getString(R.string.sync_never)
    }

    private fun renderMyWidgets() {
        val box = find<LinearLayout>(R.id.my_widgets)
        box.removeAllViews()
        val placed = WidgetUpdater.placedWidgets(this)
        if (placed.isEmpty()) {
            box.addView(textView(R.style.Text_Body, 14f).apply { setText(R.string.my_widgets_empty) })
            return
        }
        for ((id, type) in placed) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setBackgroundResource(R.drawable.bg_card)
                setPadding(dpInt(16), dpInt(12), dpInt(12), dpInt(12))
            }
            val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            col.addView(textView(R.style.Text, 15f, bold = true).apply {
                text = getString(type.design.nameRes) + " · " + type.sizeLabel
            })
            val cfg = store.widgetConfig(id)
            if (cfg != null) {
                col.addView(textView(R.style.Text_Caption, 12f).apply {
                    text = (if (cfg.lang == Lang.AR) "العربية" else "English") + " · " + cfg.opacity + "%"
                })
            }
            row.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(TextView(this, null, 0, R.style.GlassButton).apply {
                setText(R.string.btn_apply_to_widget)
                setOnClickListener { applyToWidget(id, type) }
            })
            box.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = dpInt(8)
            })
        }
    }

    // ---------------------------------------------------------------------------------------
    // Actions
    // ---------------------------------------------------------------------------------------

    private fun refreshWidgetsAsync() {
        val app = applicationContext
        io.execute { WidgetUpdater.updateAll(app, WidgetRenderer.Mode.FULL) }
    }

    private fun applyToWidget(id: Int, type: WidgetType) {
        store.saveWidgetConfig(id, draft.copy(type = type))
        store.setFullyRendered(id, false)
        WidgetUpdater.updateAll(this, WidgetRenderer.Mode.FULL, setOf(id))
        toast(R.string.toast_applied)
        renderMyWidgets()
    }

    private fun addToHomeScreen() {
        val hint = find<TextView>(R.id.tv_pin_hint)
        if (PinHelper.request(this, draft)) {
            hint.visibility = View.GONE
            toast(R.string.toast_pin_requested)
        } else {
            hint.text = getString(
                R.string.pin_unsupported,
                getString(draft.type.design.nameRes) + " " + draft.type.sizeLabel
            )
            hint.visibility = View.VISIBLE
        }
    }

    private fun setSchool(school: Int) {
        if (store.school == school) return
        store.school = school
        syncControls()
        refreshWidgetsAsync()
        syncTimes(force = false)
    }

    private fun showMethodDialog() {
        val arabic = store.appLang == Lang.AR
        val ids = listOf(CalcMethods.AUTO) + CalcMethods.ALL.map { it.id }
        val names = ids.map { CalcMethods.displayName(it, arabic) }.toTypedArray()
        val current = ids.indexOf(store.method).coerceAtLeast(0)
        dialog().setTitle(R.string.method_dialog_title)
            .setSingleChoiceItems(names, current) { d, which ->
                d.dismiss()
                if (store.method != ids[which]) {
                    store.method = ids[which]
                    syncControls()
                    refreshWidgetsAsync()
                    syncTimes(force = false)
                }
            }
            .setNegativeButton(R.string.btn_cancel, null)
            .show()
    }

    private fun dialog(): AlertDialog.Builder =
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)

    // ---- background photo ------------------------------------------------------------------

    private fun pickImage() {
        val intent = if (Build.VERSION.SDK_INT >= 33) {
            Intent(MediaStore.ACTION_PICK_IMAGES)
        } else {
            Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "image/*"
            }
        }
        try {
            @Suppress("DEPRECATION")
            startActivityForResult(intent, REQ_PICK)
        } catch (e: ActivityNotFoundException) {
            toast(R.string.toast_image_failed)
        }
    }

    @Deprecated("Framework Activity API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        @Suppress("DEPRECATION")
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_PICK || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        val app = applicationContext
        io.execute {
            val name = BackgroundStore.importFromUri(app, uri)
            main.post {
                if (isDestroyed) return@post
                if (name == null) {
                    toast(R.string.toast_image_failed)
                } else {
                    updateDraft(draft.copy(bgFile = name))
                    BackgroundStore.cleanup(app, store.referencedBackgrounds())
                    renderAll()
                }
            }
        }
    }

    // ---- location & sync ---------------------------------------------------------------------

    private fun maybeAskLocationFirstRun() {
        if (store.askedLocation || LocationHelper.hasPermission(this)) return
        store.askedLocation = true
        showRationale()
    }

    private fun onLocateClicked() {
        if (LocationHelper.hasPermission(this)) doLocate() else showRationale()
    }

    private fun showRationale() {
        dialog().setTitle(R.string.loc_rationale_title)
            .setMessage(R.string.loc_rationale_body)
            .setPositiveButton(R.string.btn_allow) { _, _ ->
                requestPermissions(
                    arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION),
                    REQ_LOC
                )
            }
            .setNegativeButton(R.string.btn_not_now, null)
            .show()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != REQ_LOC) return
        if (grantResults.any { it == PackageManager.PERMISSION_GRANTED }) doLocate() else toast(R.string.toast_loc_denied)
    }

    private fun doLocate() {
        toast(R.string.toast_locating)
        LocationHelper.locate(this) { result ->
            if (isDestroyed) return@locate
            when (result) {
                is LocateResult.Success -> applyLocation(result.latitude, result.longitude, null, LocationSource.AUTO)
                LocateResult.NoPermission -> toast(R.string.toast_loc_denied)
                LocateResult.Disabled -> toast(R.string.toast_loc_disabled)
                LocateResult.Timeout -> toast(R.string.toast_loc_timeout)
            }
        }
    }

    /** Saves the place, resolves a display name in the background, then downloads the timings. */
    private fun applyLocation(lat: Double, lon: Double, name: String?, source: LocationSource) {
        store.location = LocationInfo(lat, lon, name, source)
        renderStatus()
        val app = applicationContext
        val lang = store.appLang
        io.execute {
            if (name == null) {
                LocationHelper.reverseGeocode(app, lat, lon, lang)?.let {
                    store.location = LocationInfo(lat, lon, it, source)
                }
            }
            main.post { if (!isDestroyed) { renderStatus(); syncTimes(force = true) } }
        }
    }

    private fun syncTimes(force: Boolean) {
        if (busy) return
        busy = true
        toast(R.string.toast_updating)
        val app = applicationContext
        io.execute {
            val result = try {
                Syncer.sync(app, force)
            } catch (e: Exception) {
                null
            }
            main.post {
                busy = false
                if (isDestroyed) return@post
                if (result != null && result.ok) {
                    toast(R.string.toast_updated)
                } else {
                    Toast.makeText(
                        this, getString(R.string.toast_update_failed, errorText(result?.error)), Toast.LENGTH_LONG
                    ).show()
                }
                renderAll()
            }
        }
    }

    private fun errorText(e: ApiException?): String = getString(
        when (e?.kind) {
            ApiException.Kind.NETWORK -> R.string.error_network
            ApiException.Kind.SERVER -> R.string.error_server
            else -> R.string.error_parse
        }
    )

    private fun showCitySearch() {
        val input = EditText(this).apply {
            setHint(R.string.city_dialog_hint)
            setSingleLine(true)
            setPadding(dpInt(24), dpInt(16), dpInt(24), dpInt(16))
        }
        dialog().setTitle(R.string.city_dialog_title)
            .setView(input)
            .setPositiveButton(R.string.btn_search) { _, _ ->
                val q = input.text.toString().trim()
                if (q.isNotEmpty()) searchCity(q)
            }
            .setNegativeButton(R.string.btn_cancel, null)
            .show()
    }

    private fun searchCity(query: String) {
        val app = applicationContext
        val lang = store.appLang
        io.execute {
            val results = LocationHelper.search(app, query, lang)
            main.post {
                if (isDestroyed) return@post
                when {
                    results.isEmpty() -> toast(
                        if (android.location.Geocoder.isPresent()) R.string.city_not_found else R.string.city_unavailable
                    )
                    else -> {
                        val labels = results.map { LocationHelper.describe(it) }.toTypedArray()
                        dialog().setTitle(R.string.city_pick_title)
                            .setItems(labels) { _, which ->
                                val a = results[which]
                                applyLocation(a.latitude, a.longitude, LocationHelper.shortName(a) ?: labels[which], LocationSource.MANUAL)
                            }
                            .setNegativeButton(R.string.btn_cancel, null)
                            .show()
                    }
                }
            }
        }
    }

    private fun toast(res: Int) = Toast.makeText(this, res, Toast.LENGTH_SHORT).show()

    companion object {
        private const val REQ_PICK = 11
        private const val REQ_LOC = 12
    }
}
