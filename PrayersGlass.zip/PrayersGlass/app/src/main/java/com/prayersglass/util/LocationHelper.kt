package com.prayersglass.util

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Address
import android.location.Geocoder
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import com.prayersglass.domain.Lang
import java.util.Locale

sealed class LocateResult {
    class Success(val latitude: Double, val longitude: Double) : LocateResult()
    object NoPermission : LocateResult()
    /** Location services are switched off (no enabled provider). */
    object Disabled : LocateResult()
    object Timeout : LocateResult()
}

object LocationHelper {

    private const val FRESH_MS = 10 * 60 * 1000L
    private const val TIMEOUT_MS = 15_000L

    fun hasPermission(ctx: Context): Boolean =
        ctx.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            ctx.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    /**
     * Finds the current location with the platform LocationManager (no Google Play services
     * needed). Uses a recent cached fix when there is one, otherwise waits for a fresh one.
     * [callback] is always invoked on the main thread, exactly once.
     */
    @SuppressLint("MissingPermission")
    fun locate(ctx: Context, callback: (LocateResult) -> Unit) {
        if (!hasPermission(ctx)) {
            callback(LocateResult.NoPermission)
            return
        }
        val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val providers = listOf(LocationManager.NETWORK_PROVIDER, LocationManager.GPS_PROVIDER)
            .filter { runCatching { lm.isProviderEnabled(it) }.getOrDefault(false) }
        if (providers.isEmpty()) {
            callback(LocateResult.Disabled)
            return
        }

        fun lastKnown(): Location? = providers
            .mapNotNull { runCatching { lm.getLastKnownLocation(it) }.getOrNull() }
            .maxByOrNull { it.time }

        val cached = lastKnown()
        if (cached != null && System.currentTimeMillis() - cached.time < FRESH_MS) {
            callback(LocateResult.Success(cached.latitude, cached.longitude))
            return
        }

        val handler = Handler(Looper.getMainLooper())
        var finished = false
        val listeners = ArrayList<LocationListener>()

        fun finish(result: LocateResult) {
            if (finished) return
            finished = true
            handler.removeCallbacksAndMessages(null)
            listeners.forEach { runCatching { lm.removeUpdates(it) } }
            callback(result)
        }

        for (provider in providers) {
            val listener = object : LocationListener {
                override fun onLocationChanged(location: Location) {
                    finish(LocateResult.Success(location.latitude, location.longitude))
                }

                @Deprecated("Required on API < 30")
                override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
                override fun onProviderEnabled(provider: String) {}
                override fun onProviderDisabled(provider: String) {}
            }
            listeners.add(listener)
            try {
                lm.requestLocationUpdates(provider, 0L, 0f, listener, Looper.getMainLooper())
            } catch (e: SecurityException) {
                // e.g. GPS provider while only approximate permission is granted
            } catch (e: IllegalArgumentException) {
            }
        }
        handler.postDelayed({
            val fallback = lastKnown()
            finish(
                if (fallback != null) LocateResult.Success(fallback.latitude, fallback.longitude)
                else LocateResult.Timeout
            )
        }, TIMEOUT_MS)
    }

    /** Blocking (network). Returns a short place name, or null if unavailable. */
    @Suppress("DEPRECATION")
    fun reverseGeocode(ctx: Context, lat: Double, lon: Double, lang: Lang): String? {
        if (!Geocoder.isPresent()) return null
        return try {
            val list = Geocoder(ctx, Locale.forLanguageTag(lang.tag)).getFromLocation(lat, lon, 1)
            list?.firstOrNull()?.let { shortName(it) }
        } catch (e: Exception) {
            null
        }
    }

    /** Blocking (network). Empty when the geocoder is missing or finds nothing. */
    @Suppress("DEPRECATION")
    fun search(ctx: Context, query: String, lang: Lang): List<Address> {
        if (!Geocoder.isPresent()) return emptyList()
        return try {
            Geocoder(ctx, Locale.forLanguageTag(lang.tag)).getFromLocationName(query, 6)
                ?.filter { it.hasLatitude() && it.hasLongitude() }
                ?: emptyList()
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun shortName(a: Address): String? =
        a.locality ?: a.subAdminArea ?: a.adminArea ?: a.featureName

    fun describe(a: Address): String {
        val parts = listOfNotNull(shortName(a), a.adminArea, a.countryName).distinct()
        return parts.joinToString(", ")
    }
}
