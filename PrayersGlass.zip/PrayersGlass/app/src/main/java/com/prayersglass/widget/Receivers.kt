package com.prayersglass.widget

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.prayersglass.data.SettingsStore
import com.prayersglass.glass.BackgroundStore

/** Fired by [Scheduler]: redraw the text of every widget. */
class TickReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        WidgetUpdater.updateAll(context, WidgetRenderer.Mode.TEXT)
    }
}

/** Boot, app update, clock/zone/locale changes: everything must be redrawn from scratch. */
class SystemEventsReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        WidgetUpdater.updateAll(context, WidgetRenderer.Mode.FULL)
    }
}

/** Shared behaviour of all widget providers; subclasses only declare which [WidgetType] they are. */
abstract class GlassWidgetProvider : AppWidgetProvider() {

    abstract val type: WidgetType

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        WidgetUpdater.updateAll(context, WidgetRenderer.Mode.FULL)
    }

    override fun onAppWidgetOptionsChanged(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetId: Int,
        newOptions: android.os.Bundle
    ) {
        // The user resized the widget: re-render the glass at the new size.
        WidgetUpdater.updateAll(context, WidgetRenderer.Mode.FULL, setOf(appWidgetId))
    }

    override fun onDeleted(context: Context, appWidgetIds: IntArray) {
        val store = SettingsStore.get(context)
        for (id in appWidgetIds) store.removeWidget(id)
        BackgroundStore.cleanup(context, store.referencedBackgrounds())
    }

    override fun onEnabled(context: Context) {
        RefreshJobService.ensurePeriodic(context)
    }

    override fun onDisabled(context: Context) {
        if (!WidgetUpdater.hasAnyWidget(context)) Scheduler.cancelAll(context)
    }
}

class LiquidGlass4x2Provider : GlassWidgetProvider() { override val type = WidgetType.LIQUID_GLASS_4X2 }
class NextPrayer2x2Provider : GlassWidgetProvider() { override val type = WidgetType.NEXT_PRAYER_2X2 }
class NextPrayer4x1Provider : GlassWidgetProvider() { override val type = WidgetType.NEXT_PRAYER_4X1 }
class PrayerStrip4x1Provider : GlassWidgetProvider() { override val type = WidgetType.PRAYER_STRIP_4X1 }
class PrayerCircles4x2Provider : GlassWidgetProvider() { override val type = WidgetType.PRAYER_CIRCLES_4X2 }
class MinimalGlass2x2Provider : GlassWidgetProvider() { override val type = WidgetType.MINIMAL_GLASS_2X2 }
class MinimalGlass4x1Provider : GlassWidgetProvider() { override val type = WidgetType.MINIMAL_GLASS_4X1 }
