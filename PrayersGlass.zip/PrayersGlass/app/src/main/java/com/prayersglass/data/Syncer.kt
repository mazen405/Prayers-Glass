package com.prayersglass.data

import android.content.Context
import com.prayersglass.domain.CalcParams
import com.prayersglass.widget.WidgetRenderer
import com.prayersglass.widget.WidgetUpdater
import java.time.LocalDate

/** Downloads timings for the current settings and refreshes every widget. Blocking. */
object Syncer {
    fun sync(ctx: Context, force: Boolean): SyncResult {
        val app = ctx.applicationContext
        val store = SettingsStore.get(app)
        val loc = store.location
        val params = CalcParams(loc.lat, loc.lon, store.method, store.school)
        store.lastAttemptMs = System.currentTimeMillis()
        val result = TimesRepository.ensure(app, params, LocalDate.now(), force)
        if (result.ok) {
            store.lastSyncMs = System.currentTimeMillis()
            store.lastError = null
        } else {
            store.lastError = result.error?.kind?.name ?: "UNKNOWN"
        }
        WidgetUpdater.updateAll(app, WidgetRenderer.Mode.FULL)
        return result
    }
}
