package com.prayersglass.data

import android.content.Context
import com.prayersglass.domain.CalcMethods
import com.prayersglass.domain.CalcParams
import com.prayersglass.domain.DataSource
import com.prayersglass.domain.DayTimes
import com.prayersglass.domain.PrayerCalculator
import java.io.File
import java.time.Instant
import java.time.LocalDate
import java.time.YearMonth
import java.time.ZoneId
import java.util.Locale

/** Timings ready for the engine. */
class PrayerData(
    val days: Map<LocalDate, DayTimes>,
    val zone: ZoneId,
    val location: LocationInfo,
    /** True when the numbers are placeholders used only for in-app previews. */
    val isDemo: Boolean = false
) {
    val source: DataSource
        get() = days.values.firstOrNull()?.source ?: DataSource.LOCAL
}

class SyncResult(val ok: Boolean, val error: ApiException?)

/**
 * Month-by-month cache of online timings, plus an offline calculator fallback so widgets never
 * show invented or empty numbers while the network is unavailable.
 */
object TimesRepository {

    private class Loaded(val days: Map<LocalDate, DayTimes>, val zone: String?)

    private fun dir(ctx: Context): File = File(ctx.filesDir, "times").also { it.mkdirs() }

    private fun coordKey(v: Double): String =
        String.format(Locale.US, "%.2f", v).replace('.', 'p').replace('-', 'n')

    private fun prefix(p: CalcParams): String =
        "t_${coordKey(p.latitude)}_${coordKey(p.longitude)}_m${p.method}_s${p.school}_"

    private fun file(ctx: Context, p: CalcParams, ym: YearMonth): File =
        File(dir(ctx), prefix(p) + ym.toString() + ".json")

    private fun readOnline(ctx: Context, p: CalcParams, around: LocalDate): Loaded? {
        val months = linkedSetOf(
            YearMonth.from(around.minusDays(1)),
            YearMonth.from(around),
            YearMonth.from(around.plusDays(1))
        )
        val days = HashMap<LocalDate, DayTimes>()
        var zone: String? = null
        for (ym in months) {
            val f = file(ctx, p, ym)
            if (!f.exists()) continue
            val data = try {
                CacheCodec.decode(f.readText())
            } catch (e: Exception) {
                null
            } ?: continue
            if (zone == null) zone = data.zoneId
            for (d in data.days) days[d.date] = d
        }
        return if (days.isEmpty()) null else Loaded(days, zone)
    }

    /**
     * Downloads the months needed around [today] (yesterday .. a week ahead) unless cached.
     * Blocking: call from a background thread.
     */
    fun ensure(ctx: Context, p: CalcParams, today: LocalDate, force: Boolean): SyncResult {
        val months = linkedSetOf(
            YearMonth.from(today.minusDays(1)),
            YearMonth.from(today),
            YearMonth.from(today.plusDays(7))
        )
        var error: ApiException? = null
        var anySuccess = false
        for (ym in months) {
            val f = file(ctx, p, ym)
            if (!force && f.exists()) continue
            try {
                val raw = AladhanClient.fetchMonth(p, ym.year, ym.monthValue)
                val parsed = AladhanParser.parseCalendar(raw)
                val tmp = File(f.parentFile, f.name + ".tmp")
                tmp.writeText(CacheCodec.encode(parsed))
                if (!tmp.renameTo(f)) {
                    f.writeText(tmp.readText())
                    tmp.delete()
                }
                anySuccess = true
            } catch (e: ApiException) {
                if (error == null) error = e
                if (e.kind == ApiException.Kind.NETWORK) break
            }
        }
        if (anySuccess) prune(ctx, p, today)
        val currentOk = file(ctx, p, YearMonth.from(today)).exists()
        return SyncResult(ok = currentOk && error == null, error = error)
    }

    private fun prune(ctx: Context, p: CalcParams, today: LocalDate) {
        val keepPrefix = prefix(p)
        val oldestMonth = YearMonth.from(today).minusMonths(1)
        dir(ctx).listFiles()?.forEach { f ->
            if (!f.name.startsWith("t_")) return@forEach
            if (!f.name.startsWith(keepPrefix)) {
                f.delete()
                return@forEach
            }
            val ym = f.name.removePrefix(keepPrefix).removeSuffix(".json")
            val parsed = try { YearMonth.parse(ym) } catch (e: Exception) { null }
            if (parsed != null && parsed.isBefore(oldestMonth)) f.delete()
        }
    }

    fun hasOnlineData(ctx: Context, p: CalcParams, today: LocalDate): Boolean =
        file(ctx, p, YearMonth.from(today)).exists()

    /** Builds the data set widgets and previews render from; null if nothing trustworthy exists. */
    fun load(ctx: Context, settings: SettingsStore, now: Instant): PrayerData? {
        val loc = settings.location
        val p = CalcParams(loc.lat, loc.lon, settings.method, settings.school)
        val deviceZone = ZoneId.systemDefault()
        val deviceToday = now.atZone(deviceZone).toLocalDate()

        val online = readOnline(ctx, p, deviceToday)
        if (online != null) {
            val zone = online.zone?.let { runCatching { ZoneId.of(it) }.getOrNull() } ?: deviceZone
            val zoneToday = now.atZone(zone).toLocalDate()
            if (online.days.containsKey(zoneToday)) return PrayerData(online.days, zone, loc)
        }
        // Offline fallback: only when we know the time zone of the place.
        val zone: ZoneId = when (loc.source) {
            LocationSource.DEFAULT -> ZoneId.of("Africa/Cairo")
            LocationSource.AUTO -> deviceZone
            LocationSource.MANUAL -> return null
        }
        return PrayerData(localDays(p, zone, now), zone, loc).takeIf { it.days.isNotEmpty() }
    }

    private fun localDays(p: CalcParams, zone: ZoneId, now: Instant): Map<LocalDate, DayTimes> {
        val today = now.atZone(zone).toLocalDate()
        val method = CalcMethods.forLocalCalculation(p.method)
        val out = HashMap<LocalDate, DayTimes>()
        for (offset in -1L..1L) {
            val d = today.plusDays(offset)
            try {
                out[d] = PrayerCalculator.compute(d, p.latitude, p.longitude, zone, method, p.school)
            } catch (e: IllegalStateException) {
                // Polar edge case: skip this day.
            }
        }
        return out
    }

    /** Fixed placeholder times so the gallery can be previewed before the first sync finishes. */
    fun demo(location: LocationInfo, now: Instant): PrayerData {
        val zone = ZoneId.systemDefault()
        val today = now.atZone(zone).toLocalDate()
        val times = mapOf(
            com.prayersglass.domain.Prayer.FAJR to java.time.LocalTime.of(4, 52),
            com.prayersglass.domain.Prayer.DHUHR to java.time.LocalTime.of(11, 52),
            com.prayersglass.domain.Prayer.ASR to java.time.LocalTime.of(15, 20),
            com.prayersglass.domain.Prayer.MAGHRIB to java.time.LocalTime.of(17, 58),
            com.prayersglass.domain.Prayer.ISHA to java.time.LocalTime.of(19, 20)
        )
        val days = (-1L..1L).associate { o ->
            val d = today.plusDays(o)
            d to DayTimes(d, times, null, DataSource.LOCAL)
        }
        return PrayerData(days, zone, location, isDemo = true)
    }
}
