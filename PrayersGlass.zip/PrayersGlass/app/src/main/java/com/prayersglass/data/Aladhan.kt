package com.prayersglass.data

import com.prayersglass.domain.CalcMethods
import com.prayersglass.domain.CalcParams
import com.prayersglass.domain.DataSource
import com.prayersglass.domain.DayTimes
import com.prayersglass.domain.HijriDate
import com.prayersglass.domain.Prayer
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.util.Locale

/** Failure while talking to the prayer-time service. */
class ApiException(val kind: Kind, message: String) : Exception(message) {
    enum class Kind { NETWORK, SERVER, PARSE }
}

/** One month of timings plus the IANA zone reported by the service. */
data class MonthData(val zoneId: String?, val days: List<DayTimes>)

/** Parses responses of https://api.aladhan.com/v1/calendar/{year}/{month}. */
object AladhanParser {
    private val timeRegex = Regex("(\\d{1,2}):(\\d{2})")
    private val dateFormat = DateTimeFormatter.ofPattern("dd-MM-yyyy", Locale.ROOT)

    fun parseCalendar(json: String): MonthData {
        val root = try {
            JSONObject(json)
        } catch (e: JSONException) {
            throw ApiException(ApiException.Kind.PARSE, "Invalid JSON")
        }
        if (root.optInt("code", 200) != 200) {
            throw ApiException(ApiException.Kind.SERVER, "Service code ${root.optInt("code")}")
        }
        val arr: JSONArray = root.optJSONArray("data")
            ?: throw ApiException(ApiException.Kind.PARSE, "Missing data array")
        val days = ArrayList<DayTimes>()
        var zone: String? = null
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val day = parseDay(o) ?: continue
            days.add(day)
            if (zone == null) {
                val tz = o.optJSONObject("meta")?.optString("timezone").orEmpty()
                if (tz.isNotEmpty()) zone = tz
            }
        }
        if (days.isEmpty()) throw ApiException(ApiException.Kind.PARSE, "No usable days")
        return MonthData(zone, days)
    }

    private fun parseDay(o: JSONObject): DayTimes? {
        val timings = o.optJSONObject("timings") ?: return null
        val dateObj = o.optJSONObject("date") ?: return null
        val dateStr = dateObj.optJSONObject("gregorian")?.optString("date").orEmpty()
        val date = try {
            LocalDate.parse(dateStr, dateFormat)
        } catch (e: Exception) {
            return null
        }
        val times = HashMap<Prayer, LocalTime>()
        for (p in Prayer.ALL) {
            val m = timeRegex.find(timings.optString(p.apiKey)) ?: return null
            val h = m.groupValues[1].toInt()
            val min = m.groupValues[2].toInt()
            if (h > 23 || min > 59) return null
            times[p] = LocalTime.of(h, min)
        }
        val hijri = dateObj.optJSONObject("hijri")?.let { h ->
            val d = h.optString("day").toIntOrNull()
            val y = h.optString("year").toIntOrNull()
            val month = h.optJSONObject("month")
            if (d != null && y != null && month != null) {
                HijriDate(d, month.optString("ar"), month.optString("en"), y)
            } else null
        }
        return DayTimes(date, times, hijri, DataSource.ONLINE)
    }
}

/** Compact on-disk format so widgets can read a month in well under a millisecond. */
object CacheCodec {
    fun encode(data: MonthData): String {
        val root = JSONObject()
        root.put("v", 1)
        root.put("tz", data.zoneId ?: JSONObject.NULL)
        val arr = JSONArray()
        for (d in data.days) {
            val o = JSONObject()
            o.put("d", d.date.toString())
            val t = JSONArray()
            for (p in Prayer.ALL) t.put(d.time(p).toSecondOfDay() / 60)
            o.put("t", t)
            d.hijri?.let { h ->
                o.put("h", JSONArray().put(h.day).put(h.monthAr).put(h.monthEn).put(h.year))
            }
            arr.put(o)
        }
        root.put("days", arr)
        return root.toString()
    }

    fun decode(json: String): MonthData? = try {
        val root = JSONObject(json)
        val tz = if (root.isNull("tz")) null else root.optString("tz")
        val arr = root.getJSONArray("days")
        val days = ArrayList<DayTimes>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val t = o.getJSONArray("t")
            val times = HashMap<Prayer, LocalTime>()
            Prayer.ALL.forEachIndexed { idx, p -> times[p] = LocalTime.ofSecondOfDay(t.getInt(idx) * 60L) }
            val hijri = o.optJSONArray("h")?.let { h ->
                HijriDate(h.getInt(0), h.getString(1), h.getString(2), h.getInt(3))
            }
            days.add(DayTimes(LocalDate.parse(o.getString("d")), times, hijri, DataSource.ONLINE))
        }
        MonthData(tz, days)
    } catch (e: Exception) {
        null
    }
}

/** Thin HTTP client for the Aladhan calendar endpoint (no API key is required). */
object AladhanClient {
    private const val BASE = "https://api.aladhan.com/v1/calendar"

    fun buildUrl(p: CalcParams, year: Int, month: Int): String {
        val sb = StringBuilder()
        sb.append(BASE).append('/').append(year).append('/').append(month)
        sb.append("?latitude=").append(String.format(Locale.US, "%.5f", p.latitude))
        sb.append("&longitude=").append(String.format(Locale.US, "%.5f", p.longitude))
        sb.append("&school=").append(p.school)
        // Without "method" the service picks the authority that fits the coordinates.
        if (p.method != CalcMethods.AUTO) sb.append("&method=").append(p.method)
        return sb.toString()
    }

    /** Blocking. Call from a background thread. */
    fun fetchMonth(p: CalcParams, year: Int, month: Int): String {
        val conn = try {
            URL(buildUrl(p, year, month)).openConnection() as HttpURLConnection
        } catch (e: IOException) {
            throw ApiException(ApiException.Kind.NETWORK, e.message ?: "connect")
        }
        try {
            conn.connectTimeout = 8_000
            conn.readTimeout = 12_000
            conn.requestMethod = "GET"
            conn.setRequestProperty("Accept", "application/json")
            conn.setRequestProperty("User-Agent", "PrayersGlass/1.0 (Android)")
            val code = conn.responseCode
            if (code !in 200..299) throw ApiException(ApiException.Kind.SERVER, "HTTP $code")
            return conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        } catch (e: ApiException) {
            throw e
        } catch (e: IOException) {
            throw ApiException(ApiException.Kind.NETWORK, e.message ?: "io")
        } finally {
            conn.disconnect()
        }
    }
}
