package com.prayersglass.widget

import android.app.job.JobInfo
import android.app.job.JobParameters
import android.app.job.JobScheduler
import android.app.job.JobService
import android.content.ComponentName
import android.content.Context
import com.prayersglass.data.Syncer

/** Background download of prayer timings (network required). */
class RefreshJobService : JobService() {

    override fun onStartJob(params: JobParameters): Boolean {
        Thread {
            val ok = try {
                Syncer.sync(applicationContext, force = false).ok
            } catch (e: Exception) {
                false
            }
            jobFinished(params, !ok)
        }.start()
        return true
    }

    override fun onStopJob(params: JobParameters): Boolean = true

    companion object {
        private const val PERIODIC_ID = 1001
        private const val NOW_ID = 1002
        private const val PERIOD_MS = 6L * 60 * 60 * 1000

        private fun scheduler(ctx: Context) =
            ctx.getSystemService(Context.JOB_SCHEDULER_SERVICE) as JobScheduler

        fun ensurePeriodic(ctx: Context) {
            val js = scheduler(ctx)
            if (js.getPendingJob(PERIODIC_ID) != null) return
            val info = JobInfo.Builder(PERIODIC_ID, ComponentName(ctx, RefreshJobService::class.java))
                .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                .setPeriodic(PERIOD_MS)
                .setPersisted(true)
                .build()
            js.schedule(info)
        }

        /** One-off sync as soon as a network is available. */
        fun runNow(ctx: Context) {
            val info = JobInfo.Builder(NOW_ID, ComponentName(ctx, RefreshJobService::class.java))
                .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                .build()
            scheduler(ctx).schedule(info)
        }

        fun cancelAll(ctx: Context) {
            val js = scheduler(ctx)
            js.cancel(PERIODIC_ID)
            js.cancel(NOW_ID)
        }
    }
}
