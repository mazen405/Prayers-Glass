# Release minification is disabled by default. Add rules here if you enable it.
# AppWidgetProviders and Activities are kept automatically through the manifest.
