// Top-level build file. Plugin versions are declared once here.
// AGP 8.5.x requires Gradle 8.7+ and JDK 17 (the wrapper pins Gradle 8.9).
plugins {
    id("com.android.application") version "8.5.2" apply false
    id("org.jetbrains.kotlin.android") version "1.9.24" apply false
}
