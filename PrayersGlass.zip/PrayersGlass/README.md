# Prayers Glass

Liquid-glass prayer-time widgets for Android (Kotlin, Views/RemoteViews, no third-party runtime dependencies).

## Build
JDK 17, then `./gradlew testDebugUnitTest assembleDebug` (or open in Android Studio). APK: `app/build/outputs/apk/debug/`.
CI: `.github/workflows/android.yml`.

## Structure (`app/src/main/java/com/prayersglass`)
- `domain/` pure logic: prayer engine (next prayer, DST, day rollover), Arabic/English countdown formatting, offline solar calculator fallback.
- `data/` Aladhan API client + parser, monthly cache, settings (per-widget configs, pending pin config), sync.
- `glass/` liquid-glass bitmap renderer, blur, background photo store, progress rings.
- `widget/` 5 designs / 7 widget sizes (providers), RemoteViews renderer, updater, scheduler, receivers, job service, pin helper.
- `ui/MainActivity` gallery with live previews (same renderer as real widgets), size/photo/opacity/language, pin to home screen.
- Tests: `app/src/test` (24 JUnit tests for logic).

## Update behaviour
Android does not allow per-second widget ticks. Countdown refreshes ~every minute via an inexact non-wakeup alarm (only while the device is awake); a wake-up alarm at each prayer time; 6-hourly background download. Location updates only when the app is opened.
